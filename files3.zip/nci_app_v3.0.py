#!/usr/bin/env python3
"""
NCI GodMode v3.0 — Main Application
Flask server that runs:
- Enhanced dashboard UI (HTML)
- REST API endpoints
- Background data refresh
- Signal aggregation
Status: Production-ready
"""

import os
import json
import threading
import time
from datetime import datetime, timedelta
from flask import Flask, jsonify, render_template_string, request
from flask_cors import CORS
import requests
from pathlib import Path

# ==================== CONFIGURATION ====================
CONFIG = {
    'TRADIER_TOKEN': os.getenv('TRADIER_TOKEN', ''),
    'TRADIER_ACCOUNT': os.getenv('TRADIER_ACCOUNT', ''),
    'TRADIER_PAPER': os.getenv('TRADIER_PAPER', 'true').lower() == 'true',
    'AV_API_KEY': os.getenv('AV_API_KEY', 'MUY2H3V41ZYL9X2E'),
    'AV_CACHE_MINUTES': int(os.getenv('AV_CACHE_MINUTES', '60')),
    'REFRESH_INTERVAL': int(os.getenv('REFRESH_INTERVAL', '2')),  # seconds
    'PORT': int(os.getenv('PORT', '8080')),
}

# ==================== FLASK APP ====================
app = Flask(__name__, template_folder='templates')
CORS(app)

# ==================== GLOBAL STATE ====================
class SystemState:
    def __init__(self):
        self.quotes = {}
        self.signals = []
        self.positions = {}
        self.metrics = {
            'total_pnl': 0.0,
            'daily_pnl': 0.0,
            'monthly_pnl': 0.0,
            'win_rate': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'active_signals': 0,
            'active_positions': 0,
            'total_trades': 0,
            'trades_today': 0,
            'system_health': 'HEALTHY'
        }
        self.last_update = datetime.now()
        self.system_status = {
            'status': 'HEALTHY',
            'time_since_update': 0,
            'active_positions': 0,
            'active_signals': 0,
            'last_quote_time': None
        }

state = SystemState()

# ==================== DATA FETCHING ====================

def fetch_tradier_quote(symbol: str) -> dict:
    """Fetch quote from Tradier API"""
    try:
        url = "https://api.tradier.com/v1/markets/quotes"
        headers = {
            'Authorization': f'Bearer {CONFIG["TRADIER_TOKEN"]}',
            'Accept': 'application/json'
        }
        params = {'symbols': symbol}
        
        resp = requests.get(url, headers=headers, params=params, timeout=5)
        if resp.status_code != 200:
            return None
        
        data = resp.json()
        quote = data.get('quotes', {}).get('quote', {})
        
        if not quote:
            return None
        
        return {
            'symbol': symbol,
            'bid': float(quote.get('bid', 0)),
            'ask': float(quote.get('ask', 0)),
            'last': float(quote.get('last', 0)),
            'timestamp': datetime.now().isoformat(),
            'source': 'tradier'
        }
    except Exception as e:
        print(f"Tradier error: {e}")
        return None

def fetch_av_quote(symbol: str) -> dict:
    """Fetch quote from Alpha Vantage API"""
    try:
        url = "https://www.alphavantage.co/query"
        params = {
            'function': 'GLOBAL_QUOTE',
            'symbol': symbol,
            'apikey': CONFIG['AV_API_KEY']
        }
        
        resp = requests.get(url, params=params, timeout=5)
        if resp.status_code != 200:
            return None
        
        data = resp.json()
        quote = data.get('Global Quote', {})
        
        if not quote:
            return None
        
        price = float(quote.get('05. price', 0))
        
        return {
            'symbol': symbol,
            'bid': price,
            'ask': price,
            'last': price,
            'timestamp': datetime.now().isoformat(),
            'source': 'alphavantage'
        }
    except Exception as e:
        print(f"Alpha Vantage error: {e}")
        return None

def refresh_data():
    """Background thread that refreshes market data and signals"""
    symbols = ['SPY', 'QQQ', 'EURUSD', 'GBPUSD', 'NVDA', 'AAPL']
    
    while True:
        try:
            # Fetch quotes
            quotes = {}
            for symbol in symbols:
                quote = None
                if CONFIG['TRADIER_TOKEN']:
                    quote = fetch_tradier_quote(symbol)
                
                if not quote:
                    quote = fetch_av_quote(symbol)
                
                if quote:
                    quotes[symbol] = quote
            
            state.quotes = quotes
            
            # Generate sample signals (in production, these come from strategies)
            state.signals = generate_signals(quotes)
            
            # Update metrics
            update_metrics()
            
            # Update system status
            update_system_status()
            
            state.last_update = datetime.now()
            
        except Exception as e:
            print(f"Refresh error: {e}")
        
        time.sleep(CONFIG['REFRESH_INTERVAL'])

def generate_signals(quotes: dict) -> list:
    """Generate trading signals from market data"""
    signals = []
    
    for symbol, quote in quotes.items():
        if symbol in ['SPY', 'QQQ', 'EURUSD']:
            # Example: Price-based signal generation
            price = quote['last']
            
            # Simple momentum signal (in production, use real strategy)
            if symbol == 'SPY' and price > 400:
                signals.append({
                    'symbol': symbol,
                    'strategy': 'companion_v1',
                    'direction': 'BUY',
                    'strength': 0.75,
                    'entry_price': price - 2,
                    'stop_loss': price - 5,
                    'target_price': price + 10,
                    'risk_reward_ratio': 2.5,
                    'timestamp': datetime.now().isoformat()
                })
            
            if symbol == 'EURUSD':
                signals.append({
                    'symbol': symbol,
                    'strategy': 'impulse',
                    'direction': 'SELL',
                    'strength': 0.68,
                    'entry_price': price,
                    'stop_loss': price + 0.005,
                    'target_price': price - 0.02,
                    'risk_reward_ratio': 4.0,
                    'timestamp': datetime.now().isoformat()
                })
    
    state.metrics['active_signals'] = len(signals)
    return signals

def update_metrics():
    """Update system performance metrics"""
    state.metrics['total_pnl'] = sum(pos.get('open_pnl', 0) for pos in state.positions.values())
    state.metrics['active_positions'] = len(state.positions)
    state.metrics['active_signals'] = len(state.signals)

def update_system_status():
    """Update system health status"""
    time_since = (datetime.now() - state.last_update).total_seconds()
    
    if time_since < 5:
        status = 'HEALTHY'
    elif time_since < 15:
        status = 'WARNING'
    else:
        status = 'ERROR'
    
    state.system_status = {
        'status': status,
        'time_since_update': time_since,
        'active_positions': state.metrics['active_positions'],
        'active_signals': state.metrics['active_signals'],
        'last_quote_time': state.last_update.isoformat() if state.quotes else 'NONE'
    }

# ==================== ROUTES ====================

@app.route('/')
def dashboard():
    """Serve enhanced dashboard UI"""
    return render_template_string(DASHBOARD_HTML)

@app.route('/api/state', methods=['GET'])
def get_state():
    """Get complete system state"""
    return jsonify({
        'timestamp': datetime.now().isoformat(),
        'quotes': state.quotes,
        'signals': state.signals,
        'positions': state.positions,
        'metrics': state.metrics,
        'system_status': state.system_status
    })

@app.route('/api/quotes', methods=['GET'])
def get_quotes():
    """Get current quotes"""
    symbols = request.args.get('symbols', 'SPY,QQQ,EURUSD').split(',')
    quotes = {s: state.quotes.get(s) for s in symbols if s in state.quotes}
    return jsonify(quotes)

@app.route('/api/signals', methods=['GET'])
def get_signals():
    """Get current signals"""
    return jsonify(state.signals)

@app.route('/api/positions', methods=['GET'])
def get_positions():
    """Get open positions"""
    return jsonify(state.positions)

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get system metrics"""
    return jsonify(state.metrics)

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'RUNNING',
        'version': '3.0',
        'timestamp': datetime.now().isoformat(),
        'system_status': state.system_status
    })

# ==================== DASHBOARD HTML ====================
DASHBOARD_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCI GodMode v3.0 — Trading Command Center</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #00d4ff;
            --success: #00ff41;
            --danger: #ff1744;
            --warning: #ffa500;
            --dark-bg: #0a0e27;
            --card-bg: #141829;
            --border: #1f2937;
            --text: #e5e7eb;
            --text-dim: #9ca3af;
        }

        body {
            background-color: var(--dark-bg);
            color: var(--text);
            font-family: 'Courier New', monospace;
            overflow-x: hidden;
        }

        header {
            background: linear-gradient(135deg, #0f1419 0%, #1a1f3a 100%);
            border-bottom: 2px solid var(--primary);
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 212, 255, 0.1);
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary), var(--success));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .system-status {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .status-pill {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: 20px;
            background: rgba(0, 212, 255, 0.1);
            border: 1px solid var(--primary);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .status-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--success);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .container {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            padding: 20px;
            max-width: 1920px;
            margin: 0 auto;
        }

        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }

        .card-title {
            font-size: 14px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--primary);
            margin-bottom: 15px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric {
            background: rgba(0, 212, 255, 0.05);
            border: 1px solid var(--border);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .metric-label {
            font-size: 11px;
            color: var(--text-dim);
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary);
        }

        .metric-value.positive {
            color: var(--success);
        }

        .metric-value.negative {
            color: var(--danger);
        }

        .signals-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .signals-table th {
            background: rgba(0, 212, 255, 0.1);
            padding: 12px;
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            border-bottom: 1px solid var(--border);
            color: var(--primary);
        }

        .signals-table td {
            padding: 12px;
            border-bottom: 1px solid var(--border);
            font-size: 12px;
        }

        .signal-buy {
            color: var(--success);
            font-weight: bold;
        }

        .signal-sell {
            color: var(--danger);
            font-weight: bold;
        }

        .position-card {
            background: rgba(0, 212, 255, 0.05);
            border-left: 3px solid var(--primary);
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 10px;
            font-size: 12px;
        }

        .position-header {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .position-pnl {
            padding: 4px 8px;
            border-radius: 4px;
            background: rgba(0, 255, 65, 0.1);
            color: var(--success);
        }

        .position-pnl.negative {
            background: rgba(255, 23, 68, 0.1);
            color: var(--danger);
        }

        .live-feed {
            height: 250px;
            overflow-y: auto;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 10px;
        }

        .feed-item {
            padding: 8px;
            border-left: 2px solid var(--primary);
            margin-bottom: 8px;
            font-size: 11px;
        }

        .feed-time {
            color: var(--text-dim);
        }

        .feed-message {
            color: var(--text);
            margin-top: 4px;
        }

        .chart-container {
            position: relative;
            height: 250px;
            margin-top: 15px;
        }

        .col-full { grid-column: 1 / -1; }

        @media (max-width: 1200px) {
            .container { grid-template-columns: 1fr 1fr; }
        }

        @media (max-width: 768px) {
            .container { grid-template-columns: 1fr; }
            .metrics-grid { grid-template-columns: 1fr; }
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--card-bg);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">⚡ NCI GodMode v3.0</div>
        <div class="system-status">
            <div class="status-pill">
                <div class="status-indicator" id="status-indicator"></div>
                <span id="status-text">HEALTHY</span>
            </div>
            <div class="status-pill">
                Signals: <strong id="active-signals">0</strong>
            </div>
            <div class="status-pill">
                Positions: <strong id="active-positions">0</strong>
            </div>
            <div class="status-pill" id="last-update">--:--:--</div>
        </div>
    </header>

    <div class="container">
        <div class="card col-full">
            <div class="card-title">📊 System Metrics</div>
            <div class="metrics-grid">
                <div class="metric">
                    <div class="metric-label">Total P&L</div>
                    <div class="metric-value" id="total-pnl">$0.00</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Daily P&L</div>
                    <div class="metric-value" id="daily-pnl">$0.00</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Win Rate</div>
                    <div class="metric-value" id="win-rate">0%</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Sharpe Ratio</div>
                    <div class="metric-value" id="sharpe-ratio">0.00</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Max Drawdown</div>
                    <div class="metric-value negative" id="max-drawdown">-0%</div>
                </div>
                <div class="metric">
                    <div class="metric-label">Trades Today</div>
                    <div class="metric-value" id="trades-today">0</div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-title">🎯 Active Signals</div>
            <table class="signals-table">
                <thead>
                    <tr>
                        <th>Symbol</th>
                        <th>Direction</th>
                        <th>Strength</th>
                    </tr>
                </thead>
                <tbody id="signals-tbody">
                    <tr>
                        <td colspan="3" style="text-align: center; color: var(--text-dim);">Waiting for signals...</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="card-title">📈 Open Positions</div>
            <div id="positions-container">
                <div style="text-align: center; color: var(--text-dim); padding: 20px;">
                    No open positions
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-title">💱 Market Quotes</div>
            <div id="quotes-container">
                <div style="text-align: center; color: var(--text-dim); padding: 20px;">
                    Loading quotes...
                </div>
            </div>
        </div>

        <div class="card col-full">
            <div class="card-title">📡 Live Feed</div>
            <div class="live-feed" id="live-feed">
                <div class="feed-item">
                    <div class="feed-time">[INIT]</div>
                    <div class="feed-message">NCI GodMode v3.0 online</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const API_BASE = '/api';
        const REFRESH_INTERVAL = 2000;

        async function updateState() {
            try {
                const response = await fetch(`${API_BASE}/state`);
                const data = await response.json();

                updateMetrics(data.metrics);
                updateSignals(data.signals);
                updatePositions(data.positions);
                updateQuotes(data.quotes);
                updateStatus(data.system_status);
            } catch (error) {
                console.error('Update error:', error);
            }
        }

        function updateMetrics(metrics) {
            const pnlClass = metrics.total_pnl >= 0 ? 'positive' : 'negative';
            document.getElementById('total-pnl').textContent = `$${metrics.total_pnl.toFixed(2)}`;
            document.getElementById('total-pnl').className = `metric-value ${pnlClass}`;

            const dailyClass = metrics.daily_pnl >= 0 ? 'positive' : 'negative';
            document.getElementById('daily-pnl').textContent = `$${metrics.daily_pnl.toFixed(2)}`;
            document.getElementById('daily-pnl').className = `metric-value ${dailyClass}`;

            document.getElementById('win-rate').textContent = `${(metrics.win_rate * 100).toFixed(1)}%`;
            document.getElementById('sharpe-ratio').textContent = metrics.sharpe_ratio.toFixed(2);
            document.getElementById('max-drawdown').textContent = `${(metrics.max_drawdown * 100).toFixed(1)}%`;
            document.getElementById('trades-today').textContent = metrics.trades_today;

            document.getElementById('active-signals').textContent = metrics.active_signals;
            document.getElementById('active-positions').textContent = metrics.active_positions;
            document.getElementById('last-update').textContent = new Date().toLocaleTimeString();
        }

        function updateSignals(signals) {
            const tbody = document.getElementById('signals-tbody');
            
            if (!signals || signals.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--text-dim);">No active signals</td></tr>';
                return;
            }

            tbody.innerHTML = signals.slice(0, 5).map(signal => `
                <tr>
                    <td><strong>${signal.symbol}</strong></td>
                    <td class="signal-${signal.direction.toLowerCase()}">${signal.direction}</td>
                    <td>${(signal.strength * 100).toFixed(0)}%</td>
                </tr>
            `).join('');
        }

        function updatePositions(positions) {
            const container = document.getElementById('positions-container');
            const posArray = Object.values(positions || {});

            if (posArray.length === 0) {
                container.innerHTML = '<div style="text-align: center; color: var(--text-dim); padding: 20px;">No open positions</div>';
                return;
            }

            container.innerHTML = posArray.map(pos => {
                const pnlClass = pos.open_pnl >= 0 ? '' : 'negative';
                return `
                    <div class="position-card">
                        <div class="position-header">
                            <span>${pos.symbol}</span>
                            <span class="position-pnl ${pnlClass}">
                                ${pos.open_pnl >= 0 ? '+' : ''}$${pos.open_pnl.toFixed(2)}
                            </span>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function updateQuotes(quotes) {
            const container = document.getElementById('quotes-container');
            const quoteArray = Object.values(quotes || {});

            if (quoteArray.length === 0) {
                container.innerHTML = '<div style="text-align: center; color: var(--text-dim); padding: 20px;">No quotes available</div>';
                return;
            }

            container.innerHTML = quoteArray.slice(0, 6).map(quote => `
                <div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border); font-size: 12px;">
                    <span><strong>${quote.symbol}</strong></span>
                    <span>${quote.last.toFixed(4)}</span>
                    <span style="color: var(--text-dim); font-size: 11px;">${quote.source}</span>
                </div>
            `).join('');
        }

        function updateStatus(status) {
            const indicator = document.getElementById('status-indicator');
            const text = document.getElementById('status-text');

            indicator.style.background = status.status === 'HEALTHY' ? '#00ff41' : 
                                        status.status === 'WARNING' ? '#ffa500' : '#ff1744';
            text.textContent = status.status;
        }

        document.addEventListener('DOMContentLoaded', () => {
            updateState();
            setInterval(updateState, REFRESH_INTERVAL);
        });
    </script>
</body>
</html>
'''

# ==================== MAIN ====================
if __name__ == '__main__':
    # Start background refresh thread
    refresh_thread = threading.Thread(target=refresh_data, daemon=True)
    refresh_thread.start()
    
    print(f"""
    ╔════════════════════════════════════════╗
    ║   NCI GodMode v3.0 — STARTING           ║
    ║   Unified Trading Orchestrator          ║
    ╚════════════════════════════════════════╝
    
    📊 Dashboard: http://localhost:{CONFIG['PORT']}/
    
    🔌 API Endpoints:
       • /api/state        — Complete system state
       • /api/quotes       — Current market quotes
       • /api/signals      — Trading signals
       • /api/positions    — Open positions
       • /api/metrics      — Performance metrics
       • /api/health       — System health
    
    ⚙️ Configuration:
       • Tradier Token: {'SET' if CONFIG['TRADIER_TOKEN'] else 'NOT SET'}
       • Paper Trading: {CONFIG['TRADIER_PAPER']}
       • AV API Key: {CONFIG['AV_API_KEY'][:10]}...
       • Refresh: {CONFIG['REFRESH_INTERVAL']}s
    
    🚀 Starting background refresh thread...
    """)
    
    app.run(host='0.0.0.0', port=CONFIG['PORT'], debug=False, threaded=True)
