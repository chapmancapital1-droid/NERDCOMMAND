//+------------------------------------------------------------------+
//|                    NCI_Trading_EA_MASTER_v3.0.mq4                |
//|              NERDCOMMAND Core Intelligence Trading                |
//|         MASTER SYSTEM: EMA81320 + 4 Strategies + Engulfing       |
//|    Primary: EMA Ribbon Gate | Secondary: 4-Strategy Fusion       |
//+------------------------------------------------------------------+

#property strict
#property copyright "NERDCOMMAND"
#property version   "3.0"
#property description "MASTER EA: EMA Ribbon Gate + Breakout/Stat Arb/RSI/Pairs + Engulfing"

// ========== INPUT PARAMETERS ==========
// EMA Parameters
input int EMA8 = 8;
input int EMA13 = 13;
input int EMA20 = 20;
input int H4_EMA200 = 200;                // H4 timeframe hard gate

// Entry Parameters
input double LotSize_Entry1 = 0.01;
input double LotSize_Entry2 = 0.03;
input double LotSize_Entry3 = 0.03;

// Risk Management
input int ATR_Period = 14;
input double ATR_Multiplier = 2.0;
input double DailyTarget = 10.0;          // $10 target
input double DailyStop = -5.0;            // -$5 stop

// Strategy Parameters
input int MA20_Period = 20;
input int MA50_Period = 50;
input int RSI_Period = 14;
input int Correlation_Period = 20;
input double ATR_Threshold = 15;          // Minimum ATR to filter noise
input int MinBars = 20;                   // Minimum bars for signal validity

// Filters
input bool Use_H4_Filter = true;          // EMA200 on H4 as hard gate
input bool Use_ADX = true;                // ADX strength filter
input int ADX_Period = 14;
input double ADX_Threshold = 20;
input bool Use_Session_Filter = true;     // London/NY session filter

// ========== GLOBAL STATE ==========
double entry_price = 0;
double unified_stop_loss = 0;
int entry_stage = 0;                      // 0=IDLE, 1=ENTRY1, 2=ENTRY2, 3=FULL
int trade_direction = 0;                  // 1=LONG, -1=SHORT, 0=NONE
int scalp_wins_count = 0;
double daily_pnl = 0;
bool trading_disabled_today = false;
datetime last_trading_day = 0;
int last_entry_bar = 0;                   // Prevent multiple entries same bar

//+------------------------------------------------------------------+
//| EXPERT INITIALIZATION                                            |
//+------------------------------------------------------------------+
int OnInit() {
    Print("NCI Trading EA MASTER v3.0 initialized");
    Print("EMA Gate (8/13/20) + 4 Strategies + Engulfing Pattern");
    Print("Daily Target: $", DailyTarget, " | Daily Stop: $", DailyStop);
    return INIT_SUCCEEDED;
}

void OnDeinit(const int reason) {
    Print("NCI Trading EA MASTER deinitialized");
}

//+------------------------------------------------------------------+
//| EXPERT MAIN TICK FUNCTION                                        |
//+------------------------------------------------------------------+
void OnTick() {
    ResetDailyVariables();
    daily_pnl = CalculateDailyPnL();
    
    // Daily limits
    if (daily_pnl >= DailyTarget) {
        ReducePositionSize();
        return;
    }
    if (daily_pnl <= DailyStop) {
        CloseAllPositions();
        trading_disabled_today = true;
        Alert("Daily stop hit! Trading disabled for today.");
        return;
    }
    
    // Manage existing position
    if (entry_stage == 3) {
        ManageOpenPosition();
        return;
    }
    
    // === MASTER SIGNAL GENERATION ===
    
    // GATE 1: EMA RIBBON (Primary Filter)
    int ema_signal = GetEMA_RibbonSignal();
    if (ema_signal == 0) return;  // EMA doesn't confirm = NO TRADE
    
    // GATE 2: H4 EMA200 (Hard Gate)
    if (Use_H4_Filter && !CheckH4_EMA200Gate(ema_signal)) return;
    
    // GATE 3: Session Filter
    if (Use_Session_Filter && !CheckSessionFilter()) return;
    
    // === STRATEGY SIGNALS (Secondary Confirmation) ===
    double signal_breakout, conf_breakout;
    double signal_stat_arb, conf_stat_arb;
    double signal_rsi, conf_rsi;
    double signal_engulfing, conf_engulfing;
    
    GetBreakoutSignal(signal_breakout, conf_breakout);
    GetStatArbSignal(signal_stat_arb, conf_stat_arb);
    GetRSISignal(signal_rsi, conf_rsi);
    GetEngulfingSignal(signal_engulfing, conf_engulfing);
    
    // === SIGNAL FUSION ===
    double total_confidence = 0;
    int fused_signal = FuseSignals(
        ema_signal, 1.5,                    // EMA weighted high
        signal_breakout, conf_breakout,
        signal_stat_arb, conf_stat_arb,
        signal_rsi, conf_rsi,
        signal_engulfing, conf_engulfing,
        total_confidence
    );
    
    if (fused_signal == 0) return;
    
    // Prevent multiple entries same bar
    if (last_entry_bar == Bar) return;
    
    // === EXECUTE ENTRIES ===
    if (entry_stage == 0) {
        Entry_Stage1(fused_signal);
        last_entry_bar = Bar;
    }
    else if (entry_stage == 1 && PriceMovingInOurFavor(fused_signal)) {
        Entry_Stage2(fused_signal);
    }
    else if (entry_stage == 2 && PriceMovingInOurFavor(fused_signal)) {
        Entry_Stage3(fused_signal);
    }
    
    // Update globals for indicator
    GlobalVariableSet("NCI_Entry_Price", entry_price);
    GlobalVariableSet("NCI_Stop_Loss", unified_stop_loss);
    GlobalVariableSet("NCI_Entry_Stage", entry_stage);
    GlobalVariableSet("NCI_Scalp_Count", scalp_wins_count);
    GlobalVariableSet("NCI_Daily_PnL", daily_pnl);
    GlobalVariableSet("NCI_EMA_Signal", ema_signal);
}

//+------------------------------------------------------------------+
//| GATE 1: EMA RIBBON SIGNAL (8/13/20)                              |
//+------------------------------------------------------------------+
int GetEMA_RibbonSignal() {
    double ema8 = iMA(Symbol(), 0, EMA8, 0, MODE_EMA, PRICE_CLOSE, 0);
    double ema13 = iMA(Symbol(), 0, EMA13, 0, MODE_EMA, PRICE_CLOSE, 0);
    double ema20 = iMA(Symbol(), 0, EMA20, 0, MODE_EMA, PRICE_CLOSE, 0);
    
    double current_close = Close[0];
    
    // UPTREND: 8 > 13 > 20 and price > 8
    if (ema8 > ema13 && ema13 > ema20 && current_close > ema8) {
        return 1;  // BUY signal
    }
    
    // DOWNTREND: 8 < 13 < 20 and price < 8
    if (ema8 < ema13 && ema13 < ema20 && current_close < ema8) {
        return -1; // SELL signal
    }
    
    return 0;  // No clear trend
}

//+------------------------------------------------------------------+
//| GATE 2: H4 EMA200 Hard Gate                                       |
//+------------------------------------------------------------------+
bool CheckH4_EMA200Gate(int signal) {
    double h4_ema200 = iMA(Symbol(), PERIOD_H4, H4_EMA200, 0, MODE_EMA, PRICE_CLOSE, 0);
    double h4_close = iClose(Symbol(), PERIOD_H4, 0);
    
    // BUY only if H4 close > H4 EMA200
    if (signal == 1 && h4_close > h4_ema200) return true;
    
    // SELL only if H4 close < H4 EMA200
    if (signal == -1 && h4_close < h4_ema200) return true;
    
    return false;
}

//+------------------------------------------------------------------+
//| GATE 3: Session Filter (London 8-12 GMT, NY 13-17 GMT)           |
//+------------------------------------------------------------------+
bool CheckSessionFilter() {
    int hour = Hour();
    
    // London session: 8-12 GMT
    if (hour >= 8 && hour <= 12) return true;
    
    // NY session: 13-17 GMT
    if (hour >= 13 && hour <= 17) return true;
    
    // Off-hours
    return false;
}

//+------------------------------------------------------------------+
//| STRATEGY 1: Breakout (20-day high/low)                           |
//+------------------------------------------------------------------+
void GetBreakoutSignal(double &signal, double &confidence) {
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA20_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA20_Period, 0));
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    
    if (Close[0] > high20) {
        signal = 1;
        confidence = 0.8;
    }
    else if (Close[0] < low20) {
        signal = -1;
        confidence = 0.8;
    }
    else if (Close[0] < ma50) {
        signal = 0;
        confidence = 1.0;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| STRATEGY 2: Statistical Arbitrage (Mean Reversion)               |
//+------------------------------------------------------------------+
void GetStatArbSignal(double &signal, double &confidence) {
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    double deviation = MathAbs(Close[0] - ma50) / ma50 * 100;
    
    if (deviation > 2) {
        if (Close[0] > ma50) {
            signal = -1;  // SELL (price too high)
        } else {
            signal = 1;   // BUY (price too low)
        }
        confidence = 0.9;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| STRATEGY 3: Mean Reversion (RSI)                                 |
//+------------------------------------------------------------------+
void GetRSISignal(double &signal, double &confidence) {
    double rsi = iRSI(Symbol(), 0, RSI_Period, PRICE_CLOSE, 0);
    
    if (rsi < 30) {
        signal = 1;
        confidence = 0.7;
    }
    else if (rsi > 70) {
        signal = -1;
        confidence = 0.7;
    }
    else if (rsi == 50) {
        signal = 0;
        confidence = 1.0;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| STRATEGY 4: Engulfing Pattern (Bullish/Bearish)                  |
//+------------------------------------------------------------------+
void GetEngulfingSignal(double &signal, double &confidence) {
    double c0 = Close[0], o0 = Open[0];
    double c1 = Close[1], o1 = Open[1];
    double h1 = High[1], l1 = Low[1];
    
    // Bullish Engulfing
    if (c0 > o0 && o0 < l1 && c0 > h1) {
        signal = 1;
        confidence = 0.85;
    }
    // Bearish Engulfing
    else if (c0 < o0 && o0 > h1 && c0 < l1) {
        signal = -1;
        confidence = 0.85;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| SIGNAL FUSION (EMA Gate + 4 Strategies)                           |
//+------------------------------------------------------------------+
int FuseSignals(
    double ema_sig, double ema_conf,
    double s1, double c1,
    double s2, double c2,
    double s3, double c3,
    double s4, double c4,
    double &total_conf) {
    
    double weighted_conf = 0;
    int signal_direction = 0;
    
    // EMA is gate + high weight
    if (ema_sig != 0) {
        weighted_conf += ema_conf;
        signal_direction = (int)ema_sig;
    }
    
    // Other strategies add confidence
    if (s1 != 0 && (int)s1 == signal_direction) weighted_conf += c1 * 1.0;
    if (s2 != 0 && (int)s2 == signal_direction) weighted_conf += c2 * 1.2;
    if (s3 != 0 && (int)s3 == signal_direction) weighted_conf += c3 * 0.8;
    if (s4 != 0 && (int)s4 == signal_direction) weighted_conf += c4 * 1.1;
    
    total_conf = weighted_conf;
    
    // High confidence = trade
    if (weighted_conf > 2.0) {
        return signal_direction;
    }
    else if (weighted_conf > 1.5) {
        return signal_direction;
    }
    
    return 0;
}

//+------------------------------------------------------------------+
//| ENTRY STAGE 1 (0.01 lots)                                         |
//+------------------------------------------------------------------+
void Entry_Stage1(int direction) {
    trade_direction = direction;
    entry_price = Ask;
    
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry1, Ask, 2, 0, 0, "M3.0_Entry1", 0, 0, clrGreen);
    }
    else if (direction == -1) {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry1, Bid, 2, 0, 0, "M3.0_Entry1", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 1;
        Print("MASTER v3.0 - Entry Stage 1 at ", entry_price);
    }
}

//+------------------------------------------------------------------+
//| ENTRY STAGE 2 (0.01 + 0.03)                                      |
//+------------------------------------------------------------------+
void Entry_Stage2(int direction) {
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry2, Ask, 2, 0, 0, "M3.0_Entry2", 0, 0, clrGreen);
    }
    else {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry2, Bid, 2, 0, 0, "M3.0_Entry2", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 2;
        Print("MASTER v3.0 - Entry Stage 2 at ", Ask);
    }
}

//+------------------------------------------------------------------+
//| ENTRY STAGE 3 (0.01 + 0.03 + 0.03 = 0.07 FULL)                   |
//+------------------------------------------------------------------+
void Entry_Stage3(int direction) {
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry3, Ask, 2, 0, 0, "M3.0_Entry3", 0, 0, clrGreen);
    }
    else {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry3, Bid, 2, 0, 0, "M3.0_Entry3", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 3;
        Print("MASTER v3.0 - Entry Stage 3 (FULL 0.07) at ", Ask);
        
        // Set unified stop loss
        double atr = iATR(Symbol(), 0, ATR_Period, 0);
        double stop_distance = atr * ATR_Multiplier;
        
        if (trade_direction == 1) {
            unified_stop_loss = entry_price - stop_distance;
        } else {
            unified_stop_loss = entry_price + stop_distance;
        }
    }
}

//+------------------------------------------------------------------+
//| MANAGE OPEN POSITION (Trailing Stop, Scalp Exit)                |
//+------------------------------------------------------------------+
void ManageOpenPosition() {
    double atr = iATR(Symbol(), 0, ATR_Period, 0);
    double stop_distance = atr * ATR_Multiplier;
    
    if (trade_direction == 1) {
        double new_stop = Close[0] - stop_distance;
        if (new_stop > unified_stop_loss) {
            unified_stop_loss = new_stop;
        }
        
        if (Bid < unified_stop_loss) {
            CloseAllPositions();
            Print("MASTER v3.0 - Stop loss hit (LONG)");
            return;
        }
    }
    else if (trade_direction == -1) {
        double new_stop = Close[0] + stop_distance;
        if (new_stop < unified_stop_loss) {
            unified_stop_loss = new_stop;
        }
        
        if (Ask > unified_stop_loss) {
            CloseAllPositions();
            Print("MASTER v3.0 - Stop loss hit (SHORT)");
            return;
        }
    }
    
    CheckScalpExit();
}

//+------------------------------------------------------------------+
//| 3-TRADE SCALP EXIT                                               |
//+------------------------------------------------------------------+
void CheckScalpExit() {
    double pnl = 0;
    
    if (trade_direction == 1) {
        pnl = (Close[0] - entry_price) * 100000;
    }
    else if (trade_direction == -1) {
        pnl = (entry_price - Close[0]) * 100000;
    }
    
    if (pnl >= 10) {
        scalp_wins_count++;
        
        if (scalp_wins_count >= 3) {
            CloseAllPositions();
            Print("MASTER v3.0 - 3-Trade scalp target hit!");
            scalp_wins_count = 0;
            entry_stage = 0;
            trade_direction = 0;
        }
    }
}

//+------------------------------------------------------------------+
//| HELPER: Price Moving in Our Favor                                |
//+------------------------------------------------------------------+
bool PriceMovingInOurFavor(int direction) {
    if (direction == 1 && Close[0] > entry_price) return true;
    if (direction == -1 && Close[0] < entry_price) return true;
    return false;
}

//+------------------------------------------------------------------+
//| HELPER: Close All Positions                                       |
//+------------------------------------------------------------------+
void CloseAllPositions() {
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                if (OrderType() == OP_BUY) {
                    OrderClose(OrderTicket(), OrderOpenPrice(), Bid, 2, clrRed);
                }
                else if (OrderType() == OP_SELL) {
                    OrderClose(OrderTicket(), OrderOpenPrice(), Ask, 2, clrGreen);
                }
            }
        }
    }
    entry_stage = 0;
    trade_direction = 0;
    scalp_wins_count = 0;
}

//+------------------------------------------------------------------+
//| HELPER: Reduce Position Size (Daily Target Hit)                  |
//+------------------------------------------------------------------+
void ReducePositionSize() {
    int position_count = 0;
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                position_count++;
            }
        }
    }
    
    if (position_count > 1) {
        int count = 0;
        for (int i = OrdersTotal() - 1; i >= 0; i--) {
            if (OrderSelect(i, SELECT_BY_POS)) {
                if (OrderSymbol() == Symbol()) {
                    count++;
                    if (count % 2 == 0) {
                        if (OrderType() == OP_BUY) {
                            OrderClose(OrderTicket(), OrderOpenPrice(), Bid, 2, clrOrange);
                        }
                        else {
                            OrderClose(OrderTicket(), OrderOpenPrice(), Ask, 2, clrOrange);
                        }
                    }
                }
            }
        }
    }
    Alert("Daily target hit! Position size reduced.");
}

//+------------------------------------------------------------------+
//| HELPER: Calculate Daily P&L                                      |
//+------------------------------------------------------------------+
double CalculateDailyPnL() {
    double total_pnl = 0;
    
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                if (OrderType() == OP_BUY) {
                    total_pnl += (Bid - OrderOpenPrice()) * OrderOpenPrice() * OrderOpenPrice();
                }
                else if (OrderType() == OP_SELL) {
                    total_pnl += (OrderOpenPrice() - Ask) * OrderOpenPrice() * OrderOpenPrice();
                }
            }
        }
    }
    
    return total_pnl;
}

//+------------------------------------------------------------------+
//| HELPER: Reset Daily Variables                                    |
//+------------------------------------------------------------------+
void ResetDailyVariables() {
    datetime current_time = TimeCurrent();
    datetime current_day = StrToTime(TimeToStr(current_time, TIME_DATE));
    
    if (current_day != last_trading_day) {
        last_trading_day = current_day;
        daily_pnl = 0;
        trading_disabled_today = false;
        scalp_wins_count = 0;
    }
}

//+------------------------------------------------------------------+
//| HELPER: Get Current Bar Number                                   |
//+------------------------------------------------------------------+
int Bar = 0;

//+------------------------------------------------------------------+
