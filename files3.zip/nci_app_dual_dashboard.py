#!/usr/bin/env python3
"""
NCI GodMode v3.0 — Dual Dashboard System
- Route /              → User's Custom Dashboard
- Route /market-monitor → Trading Assistant Market Monitor
Both feed from unified REST API
"""

import os
import json
import threading
import time
from datetime import datetime, timedelta
from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
from pathlib import Path

# ==================== CONFIGURATION ====================
CONFIG = {
    'TRADIER_TOKEN': os.getenv('TRADIER_TOKEN', ''),
    'TRADIER_ACCOUNT': os.getenv('TRADIER_ACCOUNT', ''),
    'TRADIER_PAPER': os.getenv('TRADIER_PAPER', 'true').lower() == 'true',
    'AV_API_KEY': os.getenv('AV_API_KEY', 'MUY2H3V41ZYL9X2E'),
    'AV_CACHE_MINUTES': int(os.getenv('AV_CACHE_MINUTES', '60')),
    'REFRESH_INTERVAL': int(os.getenv('REFRESH_INTERVAL', '2')),
    'PORT': int(os.getenv('PORT', '8080')),
}

# ==================== FLASK APP ====================
app = Flask(__name__, template_folder='templates')
CORS(app)

# ==================== GLOBAL STATE ====================
class SystemState:
    def __init__(self):
        self.quotes = {}
        self.signals = []
        self.positions = {}
        self.alerts = []
        self.metrics = {
            'total_pnl': 0.0,
            'daily_pnl': 0.0,
            'monthly_pnl': 0.0,
            'win_rate': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'active_signals': 0,
            'active_positions': 0,
            'total_trades': 0,
            'trades_today': 0,
            'system_health': 'HEALTHY'
        }
        self.last_update = datetime.now()
        self.system_status = {
            'status': 'HEALTHY',
            'time_since_update': 0,
            'active_positions': 0,
            'active_signals': 0,
            'last_quote_time': None
        }

state = SystemState()

# ==================== DATA FETCHING ====================

def fetch_tradier_quote(symbol: str) -> dict:
    """Fetch quote from Tradier API"""
    try:
        url = "https://api.tradier.com/v1/markets/quotes"
        headers = {
            'Authorization': f'Bearer {CONFIG["TRADIER_TOKEN"]}',
            'Accept': 'application/json'
        }
        params = {'symbols': symbol}
        
        resp = requests.get(url, headers=headers, params=params, timeout=5)
        if resp.status_code != 200:
            return None
        
        data = resp.json()
        quote = data.get('quotes', {}).get('quote', {})
        
        if not quote:
            return None
        
        return {
            'symbol': symbol,
            'bid': float(quote.get('bid', 0)),
            'ask': float(quote.get('ask', 0)),
            'last': float(quote.get('last', 0)),
            'timestamp': datetime.now().isoformat(),
            'source': 'tradier'
        }
    except Exception as e:
        print(f"Tradier error: {e}")
        return None

def fetch_av_quote(symbol: str) -> dict:
    """Fetch quote from Alpha Vantage API"""
    try:
        url = "https://www.alphavantage.co/query"
        params = {
            'function': 'GLOBAL_QUOTE',
            'symbol': symbol,
            'apikey': CONFIG['AV_API_KEY']
        }
        
        resp = requests.get(url, params=params, timeout=5)
        if resp.status_code != 200:
            return None
        
        data = resp.json()
        quote = data.get('Global Quote', {})
        
        if not quote:
            return None
        
        price = float(quote.get('05. price', 0))
        
        return {
            'symbol': symbol,
            'bid': price,
            'ask': price,
            'last': price,
            'timestamp': datetime.now().isoformat(),
            'source': 'alphavantage'
        }
    except Exception as e:
        print(f"Alpha Vantage error: {e}")
        return None

def refresh_data():
    """Background thread that refreshes market data and signals"""
    symbols = ['SPY', 'QQQ', 'EURUSD', 'GBPUSD', 'NVDA', 'AAPL']
    
    while True:
        try:
            # Fetch quotes
            quotes = {}
            for symbol in symbols:
                quote = None
                if CONFIG['TRADIER_TOKEN']:
                    quote = fetch_tradier_quote(symbol)
                
                if not quote:
                    quote = fetch_av_quote(symbol)
                
                if quote:
                    quotes[symbol] = quote
            
            state.quotes = quotes
            
            # Generate sample signals
            state.signals = generate_signals(quotes)
            
            # Generate alerts
            state.alerts = generate_alerts(quotes)
            
            # Update metrics
            update_metrics()
            
            # Update system status
            update_system_status()
            
            state.last_update = datetime.now()
            
        except Exception as e:
            print(f"Refresh error: {e}")
        
        time.sleep(CONFIG['REFRESH_INTERVAL'])

def generate_signals(quotes: dict) -> list:
    """Generate trading signals from market data"""
    signals = []
    
    for symbol, quote in quotes.items():
        if symbol in ['SPY', 'QQQ', 'EURUSD']:
            price = quote['last']
            
            if symbol == 'SPY' and price > 500:
                signals.append({
                    'symbol': symbol,
                    'strategy': 'companion_v1',
                    'direction': 'BUY',
                    'strength': 0.85,
                    'entry_price': price - 2,
                    'stop_loss': price - 5,
                    'target_price': price + 10,
                    'timestamp': datetime.now().isoformat()
                })
            
            if symbol == 'EURUSD':
                signals.append({
                    'symbol': symbol,
                    'strategy': 'impulse',
                    'direction': 'SELL',
                    'strength': 0.72,
                    'entry_price': price,
                    'stop_loss': price + 0.005,
                    'target_price': price - 0.02,
                    'timestamp': datetime.now().isoformat()
                })
    
    state.metrics['active_signals'] = len(signals)
    return signals

def generate_alerts(quotes: dict) -> list:
    """Generate trading alerts"""
    alerts = []
    
    if 'QQQ' in quotes and quotes['QQQ']['last'] > 449:
        alerts.append({
            'level': 'CRITICAL',
            'symbol': 'QQQ',
            'message': 'QQQ breakout above 449.50 detected - HIGH VOLUME',
            'timestamp': datetime.now().isoformat()
        })
    
    if 'EURUSD' in quotes and quotes['EURUSD']['last'] < 1.051:
        alerts.append({
            'level': 'WARNING',
            'symbol': 'EURUSD',
            'message': 'EURUSD approached support at 1.0490',
            'timestamp': datetime.now().isoformat()
        })
    
    return alerts

def update_metrics():
    """Update system performance metrics"""
    state.metrics['total_pnl'] = sum(pos.get('open_pnl', 0) for pos in state.positions.values())
    state.metrics['active_positions'] = len(state.positions)
    state.metrics['active_signals'] = len(state.signals)

def update_system_status():
    """Update system health status"""
    time_since = (datetime.now() - state.last_update).total_seconds()
    
    if time_since < 5:
        status = 'HEALTHY'
    elif time_since < 15:
        status = 'WARNING'
    else:
        status = 'ERROR'
    
    state.system_status = {
        'status': status,
        'time_since_update': time_since,
        'active_positions': state.metrics['active_positions'],
        'active_signals': state.metrics['active_signals'],
        'last_quote_time': state.last_update.isoformat() if state.quotes else 'NONE'
    }

# ==================== ROUTES: DASHBOARDS ====================

# User Custom Dashboard (localhost:8080/)
USER_DASHBOARD = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCI GodMode v3.0 — User Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #00d4ff;
            --success: #00ff41;
            --danger: #ff1744;
            --dark-bg: #0a0e27;
            --card-bg: #141829;
            --border: #1f2937;
            --text: #e5e7eb;
        }
        body {
            background: var(--dark-bg);
            color: var(--text);
            font-family: 'Courier New', monospace;
        }
        header {
            background: linear-gradient(135deg, #0f1419 0%, #1a1f3a 100%);
            border-bottom: 2px solid var(--primary);
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary), var(--success));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-buttons {
            display: flex;
            gap: 15px;
        }
        .btn {
            padding: 10px 20px;
            background: rgba(0, 212, 255, 0.2);
            border: 1px solid var(--primary);
            border-radius: 6px;
            color: var(--primary);
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background: rgba(0, 212, 255, 0.3);
            box-shadow: 0 0 10px rgba(0, 212, 255, 0.3);
        }
        .btn.active {
            background: rgba(0, 212, 255, 0.4);
            box-shadow: 0 0 15px rgba(0, 212, 255, 0.5);
        }
        .container {
            padding: 30px;
            text-align: center;
        }
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 30px;
            margin: 20px auto;
            max-width: 600px;
        }
        h1 { margin: 20px 0; color: var(--primary); }
        p { margin: 15px 0; color: var(--text); }
        .metric { font-size: 24px; font-weight: bold; color: var(--success); }
    </style>
</head>
<body>
    <header>
        <div class="logo">⚡ NCI GodMode v3.0 — User Dashboard</div>
        <div class="nav-buttons">
            <button class="btn active" onclick="location.hash='#user'">User Dashboard</button>
            <button class="btn" onclick="location.href='/market-monitor'">Market Monitor</button>
            <button class="btn" onclick="location.href='/api/state'">API</button>
        </div>
    </header>
    <div class="container">
        <h1>Welcome to Your NCI Trading Command Center</h1>
        <div class="card">
            <h2>📊 Your Trading Summary</h2>
            <p>Total P&L: <span class="metric" id="total-pnl">$0.00</span></p>
            <p>Today's P&L: <span class="metric" id="daily-pnl">$0.00</span></p>
            <p>Active Signals: <span class="metric" id="signals">0</span></p>
            <p>Open Positions: <span class="metric" id="positions">0</span></p>
        </div>
        <div class="card">
            <h2>🎯 Quick Links</h2>
            <p><a class="btn" href="/api/state">View System State (JSON)</a></p>
            <p><a class="btn" href="/market-monitor">Go to Market Monitor →</a></p>
        </div>
    </div>
    <script>
        async function updateDashboard() {
            try {
                const res = await fetch('/api/state');
                const data = await res.json();
                document.getElementById('total-pnl').textContent = `$${data.metrics.total_pnl.toFixed(2)}`;
                document.getElementById('daily-pnl').textContent = `$${data.metrics.daily_pnl.toFixed(2)}`;
                document.getElementById('signals').textContent = data.metrics.active_signals;
                document.getElementById('positions').textContent = data.metrics.active_positions;
            } catch(e) { console.error(e); }
        }
        updateDashboard();
        setInterval(updateDashboard, 2000);
    </script>
</body>
</html>'''

@app.route('/')
def user_dashboard():
    """Serve user's custom dashboard"""
    return USER_DASHBOARD

# Read market monitor HTML
with open('/home/claude/market_monitor_dashboard.html', 'r') as f:
    MARKET_MONITOR_HTML = f.read()

@app.route('/market-monitor')
def market_monitor():
    """Serve trading assistant market monitoring dashboard"""
    return MARKET_MONITOR_HTML

# ==================== API ROUTES ====================

@app.route('/api/state', methods=['GET'])
def get_state():
    """Get complete system state"""
    return jsonify({
        'timestamp': datetime.now().isoformat(),
        'quotes': state.quotes,
        'signals': state.signals,
        'positions': state.positions,
        'alerts': state.alerts,
        'metrics': state.metrics,
        'system_status': state.system_status
    })

@app.route('/api/quotes', methods=['GET'])
def get_quotes():
    """Get current quotes"""
    symbols = request.args.get('symbols', 'SPY,QQQ,EURUSD').split(',')
    quotes = {s: state.quotes.get(s) for s in symbols if s in state.quotes}
    return jsonify(quotes)

@app.route('/api/signals', methods=['GET'])
def get_signals():
    """Get current signals"""
    return jsonify(state.signals)

@app.route('/api/alerts', methods=['GET'])
def get_alerts():
    """Get trading alerts"""
    return jsonify(state.alerts)

@app.route('/api/positions', methods=['GET'])
def get_positions():
    """Get open positions"""
    return jsonify(state.positions)

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get system metrics"""
    return jsonify(state.metrics)

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'RUNNING',
        'version': '3.0',
        'timestamp': datetime.now().isoformat(),
        'system_status': state.system_status,
        'dashboards': {
            'user': 'http://localhost:8080/',
            'market_monitor': 'http://localhost:8080/market-monitor'
        }
    })

# ==================== BACKGROUND REFRESH ====================

def start_background_refresh():
    """Start background refresh thread"""
    refresh_thread = threading.Thread(target=refresh_data, daemon=True)
    refresh_thread.start()

# ==================== MAIN ====================

if __name__ == '__main__':
    start_background_refresh()
    
    print(f"""
    ╔════════════════════════════════════════════════╗
    ║   NCI GodMode v3.0 — Dual Dashboard System     ║
    ║   Unified Trading Orchestrator                  ║
    ╚════════════════════════════════════════════════╝
    
    📊 DASHBOARDS:
       • User Dashboard:    http://localhost:{CONFIG['PORT']}/
       • Market Monitor:    http://localhost:{CONFIG['PORT']}/market-monitor
    
    🔌 API ENDPOINTS:
       • /api/state        — Complete system state
       • /api/quotes       — Current market quotes
       • /api/signals      — Trading signals
       • /api/alerts       — Trading alerts
       • /api/positions    — Open positions
       • /api/metrics      — Performance metrics
       • /api/health       — System health
    
    ⚙️ CONFIGURATION:
       • Tradier Token: {'SET' if CONFIG['TRADIER_TOKEN'] else 'NOT SET'}
       • Paper Trading: {CONFIG['TRADIER_PAPER']}
       • AV API Key: {CONFIG['AV_API_KEY'][:10]}...
       • Refresh: {CONFIG['REFRESH_INTERVAL']}s
    
    🚀 Starting background refresh thread...
    
    🌐 Serving on http://0.0.0.0:{CONFIG['PORT']}
    """)
    
    app.run(host='0.0.0.0', port=CONFIG['PORT'], debug=False, threaded=True)
