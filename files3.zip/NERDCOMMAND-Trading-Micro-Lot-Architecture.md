# NERDCOMMAND TRADING — Micro-Lot, Capital Preservation Architecture

## Executive Summary

**You're building a lean, smart trading operation that:**
- Starts from **zero capital** (build up from $100-500)
- Uses **0.01-0.07 lot sizes** (micro risk, big learnings)
- Employs **4 proven strategies** (breakout, stat arb, mean reversion, pairs)
- Implements **one unified stop loss** (no confusion, known risk)
- Executes **3-trade scalps** (exit before reversals)
- Preserves **capital above all** (don't blow up, grow steadily)

**Goal**: Grow $500 → $3000+ in 12 months (20% monthly) through consistent small wins.

---

## Core Philosophy

### ✅ DO THIS:
- Trade only **high-conviction signals** (multiple strategies agree)
- Exit **winners quickly** (3 trades = done, lock profit)
- **Protect capital** (stop hits = accept loss, learn, move on)
- **Keep position sizes tiny** (0.01-0.07 lots = training wheels)
- **Monitor obsessively** (watch price action, override if needed)
- **Log everything** (learn from every trade)

### ❌ DON'T DO THIS:
- **Average down** into losing trades (no martingale)
- Trade **low-conviction signals** (wait for multiple strategies)
- Hold **overnight** (scalp intraday, no overnight risk)
- Use **leverage** (you don't have enough capital to survive it)
- **Ignore stops** (discipline = survival)
- **Revenge trade** after losses (respect daily limits)

---

## The 4 Strategies

### Strategy 1: Breakout Trader
```
Entry: Price breaks above 20-day high (BUY) or below 20-day low (SELL)
Exit: On close below 50-day moving average OR after 3 winning scalps
Confidence: 1x (base signal)
Best for: Trending pairs (EURUSD, GBPUSD, AUDUSD)
Win rate expectation: 50-55%
```

### Strategy 2: Statistical Arbitrage
```
Entry: Pair correlation diverges >2 standard deviations
  Example: AAPL and MSFT usually move together. If AAPL up 5% and MSFT flat,
           spread is wide. Bet on reversion (short AAPL or long MSFT).
Exit: After 3 winning scalps OR spread returns to 1 std dev
Confidence: 1.2x (more reliable, market-neutral)
Best for: Highly correlated pairs (tech stocks, currency pairs in same region)
Win rate expectation: 55-60%
```

### Strategy 3: Crypto Mean Reversion (RSI)
```
Entry: RSI < 30 (oversold, buy) or RSI > 70 (overbought, sell)
Exit: RSI crosses 50 level OR after 3 winning scalps
Confidence: 0.8x (faster, noisier, prone to false signals)
Best for: High-volatility crypto (BTC, ETH)
Win rate expectation: 48-52% (lower, but 3-trade scalps still profitable)
```

### Strategy 4: Pairs Trading
```
Entry: Pair spread > 2 std dev (long underperformer, short outperformer)
  Example: AAPL/MSFT spread widens. Long AAPL (weak), short MSFT (strong).
           Wait for mean reversion.
Exit: Spread < 1 std dev OR after 3 winning scalps
Confidence: 1.1x (market neutral, lower directional risk)
Best for: Stable pairs (AAPL/MSFT, JPM/BAC, XOM/CVX)
Win rate expectation: 52-58%
```

---

## Signal Fusion & Position Sizing

**Confidence scores combine to determine position size:**

```
If Breakout (1x) + RSI (0.8x) = 1.8x total confidence
  → MEDIUM conviction → 0.04 lots

If Breakout (1x) + Stat Arb (1.2x) + Pairs (1.1x) = 3.3x total
  → HIGH conviction → 0.07 lots (FULL SIZE)

If only RSI (0.8x) = 0.8x total
  → LOW conviction → 0.01 lots (minimal) or skip
```

**Rule**: Don't trade unless at least 2 strategies agree.

---

## Triangle Entry (Risk Management)

**Don't all-in on first signal. Build position gradually.**

```
Entry 1: 0.01 lots @ signal price
         Risk: $0.10 (if stop hits)
         Proves: Setup is real

Entry 2: +0.03 lots if price moves in our favor
         Risk: +$0.30 (total $0.40 if stopped)
         Proves: Trend is holding

Entry 3: +0.03 lots if trend continues
         Risk: +$0.30 (total $0.70 if stopped)
         Result: Full 0.07 position at good average price

If any entry hits the stop: CLOSE ALL. No averaging down.
```

**Example**:
```
EURUSD, Breakout signal at 1.0500
Entry 1: Buy 0.01 lots @ 1.0500 (risk: -100 pips to 1.0400)
Hits +20 pips → Entry 2: Buy 0.03 lots @ 1.0520
Hits +30 pips → Entry 3: Buy 0.03 lots @ 1.0550
Total: 0.07 lots @ avg 1.0524 (good entry)

If any part hits stop (1.0400): CLOSE ALL immediately.
```

---

## ONE Unified Dynamic Stop Loss

**Not per-strategy. Not per-entry. ONE stop for entire position.**

```
Stop Loss = Entry Price ± (ATR-14 × 2)

Example: EURUSD at 1.0500, ATR-14 = 50 pips
Stop = 1.0500 - (50 × 2) = 1.0400 (100 pips below entry)

As price moves in our favor, trail the stop:
Price: 1.0550 (50 pips profit), ATR = 50 pips
New stop = 1.0550 - 100 = 1.0450 (lock in 50 pips minimum)

Stop only moves UP (protecting gains), never DOWN.
If stop is hit → CLOSE ENTIRE POSITION. NO EXCEPTIONS.
```

**Why unified?** Clarity. You know exactly how much you risk. No confusion between strategies.

---

## 3-Trade Scalp Exit

**Count winning scalps. Exit after 3.**

```
Trade 1: Entry at 1.0500, close at 1.0510 (+10 pips = +$0.70)
Trade 2: Entry at 1.0510, close at 1.0525 (+15 pips = +$1.05)
Trade 3: Entry at 1.0525, close at 1.0537 (+12 pips = +$0.84)
         ↓
         EXIT ENTIRE POSITION (+$2.59 total)
         Lock in profit, move to next setup
```

**Why 3 trades?**
- Markets mean-revert after 3-4 moves
- Empirically, 4th move often reverses (your profit disappears)
- Better to take $2-3 profit consistently than chase for $5 and lose $1

---

## Price Preservation Monitoring

**Protect capital. Profits come later.**

### Daily Limits
```
Target: +$10/day (2% of $500 account)
        Hit target? → Reduce position size 50% or STOP TRADING
        Lock in profits, don't get greedy

Stop Loss: -$5/day (1% loss)
          Hit this? → CLOSE ALL POSITIONS, STOP TRADING
          Preserve capital above all else
```

### Open P&L Alerts
```
Every tick, update open P&L:
- +$5: Yellow alert (approaching target, reduce risk)
- -$2: Orange alert (halfway to stop, tighten stop)
- +$10: Green alert (hit target, close position or reduce)
- -$5: RED ALERT (stop loss, close all, stop trading)
```

### Price Action Override
**Automated stops are good, but human judgment is better.**

If you see:
- **Bad price action** (chaos, noise, reversals): Close early, take profit
- **Trending strongly**: Let it run (ignore 3-trade rule temporarily)
- **Data corruption**: Close immediately (bad tick might stop you wrongly)

---

## The 6-Week Implementation Plan

### Week 1: Setup & Breakout Strategy
- [ ] Open Interactive Brokers account
- [ ] Test market data (can you get EURUSD ticks?)
- [ ] Code: Breakout strategy (20-day high detection)
- [ ] Backtest on 6 months EURUSD
- [ ] Paper trade 3-5 days
- **Deliverable**: 10-20 paper trades logged

### Week 2: Risk Management Layer
- [ ] Code: Dynamic stop loss (2x ATR)
- [ ] Code: 3-trade exit counter
- [ ] Code: Daily P&L limits (+$10 target, -$5 stop)
- [ ] Paper trade with stops enabled
- [ ] Review: Did stops work? 3-trade rule profitable?
- **Deliverable**: Trade log showing entries, exits, stops

### Week 3: Triangle Entry & Logging
- [ ] Code: Triangle entry (0.01 → 0.03 → 0.07)
- [ ] Code: Trade logger (entry, exit, P&L, reason)
- [ ] Paper trade another week
- [ ] Analyze: Which entry phases worked best?
- **Deliverable**: Trade log + weekly analysis

### Week 4: Strategy #2 (Mean Reversion)
- [ ] Code: RSI mean reversion (buy RSI < 30)
- [ ] Code: Signal fusion (combine breakout + RSI)
- [ ] Backtest on 6 months
- [ ] Paper trade: watch for false signals
- **Deliverable**: Backtest showing combined signal

### Week 5: Strategies #3 & #4 (Stat Arb & Pairs)
- [ ] Code: Stat arb (pair correlation)
- [ ] Code: Pairs trading (spread detection)
- [ ] Integrate all 4 with weighted signals
- [ ] Test on 10-15 forex pairs
- [ ] Paper trade multi-pair
- **Deliverable**: Multi-pair paper trading log

### Week 6: Go Live ($100-500)
- [ ] Fund account with micro capital
- [ ] Live trade: same discipline as paper
- [ ] Monitor daily: paper vs. live results match?
- [ ] Weekly: +20% growth? reduce size or add capital
- [ ] Monthly: if +$100 profit, increase to $1K account
- **Deliverable**: Real trading P&L log

---

## Performance Expectations

### Conservative Monthly Growth
```
Month 1: $500 start + $50 (10% win) = $550
Month 2: $550 + $55 (10% win) = $605
Month 3: $605 + $61 (10% win) = $666
Month 4: $666 + $67 (10% win) = $733
...
Year 1: $500 → ~$1,600 (120% annual = realistic)
```

### Aggressive Monthly Growth
```
Month 1: $500 + $100 (20% win) = $600
Month 2: $600 + $120 (20% win) = $720
Month 3: $720 + $144 (20% win) = $864
Month 4: $864 + $173 (20% win) = $1,037
...
Year 1: $500 → $3,100+ (520% annual = hard, possible)
```

**Reality**: Expect 10-15% monthly (5-10% common). Be happy with it.

---

## Key Metrics to Track

| Metric | Target | Notes |
|--------|--------|-------|
| **Win rate** | >50% | 48% works if 3-trade scalps (exit early) |
| **Avg winner** | +$0.70-1.50 | 10-20 pips at 0.07 lots |
| **Avg loser** | -$0.30-0.70 | Stop at 100 pips |
| **Daily target** | +$10 | 10-15 scalps at +$0.70-1 each |
| **Daily max loss** | -$5 | Hard stop, don't exceed |
| **Win/loss ratio** | 2:1 | 2 dollars won for each 1 lost |
| **Monthly P&L** | +10-20% | Compounding grows fast |

---

## Technology Stack (Minimal, Cost <$50/month)

| Component | Technology | Cost | Why |
|-----------|-----------|------|-----|
| Data feed | Interactive Brokers API | ~$10/mo | Micro-lot support, forex specialist |
| Backup data | Oanda demo account | $0 | Free, good quotes |
| Trading | Python + IB SDK | $0 | Free, flexible |
| Position log | SQLite (local file) | $0 | Simple, no server needed |
| Performance tracking | Google Sheets | $0 | Shareable, easy analysis |
| Monitoring | Python CLI | $0 | Print P&L to terminal |
| Total | | **<$50/mo** | Bootstrapped lean |

---

## Daily Checklist

**Before Market Open**:
- [ ] System running (Python script started?)
- [ ] Data streaming (ticks coming in?)
- [ ] Daily limits set (know target +$10 and stop -$5)

**During Trading**:
- [ ] Monitor position (entry, stop level, scalp count)
- [ ] Watch price action (bad action = override, close early)
- [ ] Count wins (3 wins = exit, lock profit)
- [ ] Stop hit? (close immediately, analyze why)

**After Close**:
- [ ] Log trades (entry, exit, P&L, strategy, reason)
- [ ] Calculate daily P&L (hit target or stop?)
- [ ] Note anomalies (any surprises?)

**Weekly**:
- [ ] Review 20+ trades (win rate by strategy?)
- [ ] Check pair performance (which pairs winning/losing?)
- [ ] Adjust: improve winners, kill losers

**Monthly**:
- [ ] Full audit (200+ trades if daily trading)
- [ ] Calculate monthly return %
- [ ] Decide: grow account or reduce risk?

---

## Failure Recovery (Keep It Simple)

**Connection lost?** → Reconnect to IB. Manual close if needed. Stop loss should still work.

**Stop didn't execute?** → Close manually immediately. Review why (broker lag? connection drop?).

**Strategy failing?** → Pause that strategy. Revert to previous version. Backtest why.

**Account at -$5?** → STOP TRADING. Preserve capital. Analysis tomorrow.

**Profits approaching +$10?** → Reduce position size 50%. Lock in gains.

---

## The Mental Game

### Remember:
- **Consistency > perfection** (50% win rate is enough)
- **Capital preservation > growth** (don't blow up, compound slowly)
- **Boring profit > chased loss** (3 trades and exit is boring, but profits)
- **Stop loss is your friend** (saves you from worst losses)
- **Small position sizes are training** (0.01-0.07 lots = safe learning)

### Don't:
- Chase losses (daily stop = stop trading)
- Trade low-conviction (wait for multiple strategies)
- Override stops (discipline = survival)
- Leverage up (you'll blow up)
- Hold overnight (scalp and exit)

---

## Next Steps

1. **Open IB account** (micro-lot support, forex coverage)
2. **Test data stream** (can you pull EURUSD ticks?)
3. **Code Strategy #1** (breakout, 20-day high)
4. **Backtest 6 months** (prove it works)
5. **Paper trade 1 week** (no money risk)
6. **Fund $100-500** (real money, tiny lots)
7. **Trade with discipline** (stops, 3-trade exits, daily limits)
8. **Compound steadily** (10-20% monthly = $500 → $3K in 12 months)

---

## Integration with NERDCOMMAND Ecosystem

**Once you have consistent profits**, monetize via **stripe-integration**:
- Sell trading signals (APIs, subscriptions)
- Tier 1: $29/mo (5 signals/day via email)
- Tier 2: $99/mo (unlimited signals via webhook)
- Revenue: If 10 subscribers × $50 avg = $500/mo passive income

**But first**: Build the system, prove it works, THEN build the business.

---

**Ready to start?** Week 1 begins tomorrow. Let's build.
