# NCI Trading EA v1.0 + Indicator v1.0 — Quick Start

## What You Have

**Two MQL4 Files**:
1. **`NCI_Trading_EA_v1.mq4`** (18KB) — Auto-trading Expert Advisor
2. **`NCI_Trading_Indicator_v1.mq4`** (13KB) — Visual companion indicator

**Plus**: Architecture design document

---

## Installation (MT4)

### Step 1: Open MT4 File Explorer
1. In MT4, click **File → Open Data Folder**
2. Navigate to: `MQL4` → `Experts` (for EA) and `Indicators` (for Indicator)

### Step 2: Copy Files
- Copy `NCI_Trading_EA_v1.mq4` to `Experts` folder
- Copy `NCI_Trading_Indicator_v1.mq4` to `Indicators` folder

### Step 3: Restart MT4
Close and reopen MT4 to refresh the file cache.

### Step 4: Compile Files
- Open **Tools → MetaEditor** (or Ctrl+Shift+M)
- Open each file and compile (F5)
- Check for errors in the compilation tab

---

## How to Use

### Attaching the EA
1. Open a **forex chart** (EURUSD, GBPUSD, etc.)
2. Drag the EA onto the chart: **Expert Advisors → NCI_Trading_EA_v1**
3. Or: Right-click chart → **Attach Expert Advisor**
4. Set inputs (optional, defaults are good to start):
   - `LotSize_Entry1`: 0.01
   - `LotSize_Entry2`: 0.03
   - `LotSize_Entry3`: 0.03
   - `DailyTarget`: 10.0 (dollars)
   - `DailyStop`: -5.0 (dollars)
5. Click **OK**

### Attaching the Indicator
1. Same chart where EA is running
2. **Insert → Indicators → Custom → NCI_Trading_Indicator_v1**
3. Click **OK**
4. Indicator paints on chart, showing:
   - Support/resistance (20-day high/low)
   - Entry prices
   - Stop loss levels
   - Strategy signals (Breakout, RSI, MA divergence, Pairs)
   - Real-time dashboard with P&L

---

## What the EA Does

### Automatically:
1. **Generates signals** from 4 strategies (every tick)
2. **Fuses signals** with confidence weighting
3. **Executes triangle entries** (0.01 → 0.03 → 0.03 = 0.07 lots)
4. **Manages unified stop loss** (Entry ± 2×ATR, trails up)
5. **Counts 3-trade scalps** (exits after 3 wins)
6. **Enforces daily limits** (+$10 target, -$5 stop)

### Does NOT do automatically:
- Risk management (you set lot sizes in inputs)
- Slippage management (you set spread tolerance)
- Pair selection (you pick the pair to trade)
- Strategy optimization (uses defaults)

---

## The 4 Strategies (What It Trades)

### 1. Breakout Trader
- **Entry**: Price breaks above 20-day high (BUY) or below 20-day low (SELL)
- **Exit**: Close below 50-day MA
- **Confidence**: 1.0x
- **Win rate**: 50-55%

### 2. Statistical Arbitrage
- **Entry**: Price deviates >2% from 50-day MA (mean revert)
- **Exit**: Price within 1% of MA (normal range)
- **Confidence**: 1.2x (most reliable)
- **Win rate**: 55-60%

### 3. Mean Reversion (RSI)
- **Entry**: RSI < 30 (oversold, buy) or RSI > 70 (overbought, sell)
- **Exit**: RSI crosses 50 (neutral)
- **Confidence**: 0.8x (noisier, fewer false signals)
- **Win rate**: 48-52%

### 4. Pairs Trading
- **Entry**: Engulfing candle pattern (bullish/bearish confirmation)
- **Exit**: Pattern breaks
- **Confidence**: 1.1x
- **Win rate**: 52-58%

---

## Reading the Dashboard

The indicator displays (top-left of chart):

```
NCI TRADING EA - LIVE
Position: 0.07 lots (FULL)
Entry: 1.0500
Current: 1.0510 (P&L: +100 pips)
Stop: 1.0400
Scalp Wins: 2/3

Daily P&L: $2.50 / Target: $10 / Stop: -$5

=== STRATEGY SIGNALS ===
Breakout: BUY (1.0x)
RSI: NEUTRAL (55.2)
MA Divergence: NORMAL
Pairs: HOLD
```

**Interpretation**:
- **Position**: How many lots open (0.01, 0.04, 0.07)
- **Entry/Stop**: Where you entered and where you'll exit
- **Scalp Wins**: Count of profitable scalps (exit at 3/3)
- **Daily P&L**: Today's total profit/loss
- **Strategy Signals**: What each strategy is signaling

---

## Testing Workflow

### Week 1: Paper Trading
1. Attach EA to EURUSD 1-hour chart (paper account)
2. Attach indicator on same chart
3. Run for 3-5 days
4. Watch dashboard and indicator
5. **Check**: Do signals make sense? Do entries/exits follow the rules?
6. **Goal**: Verify EA logic works as expected

### Week 2: Optimization
1. Review paper trades
2. Adjust inputs if needed:
   - Change lot sizes
   - Change daily target/stop
   - Test different currency pairs
3. Run another 3-5 days
4. **Goal**: Understand which pairs work best, which signals are most reliable

### Week 3: Live Trading (Small Capital)
1. Fund account with $100-500
2. Start on one pair (EURUSD recommended, most liquid)
3. Reduce lot sizes if nervous:
   - Entry1: 0.005 (instead of 0.01)
   - Entry2: 0.015
   - Entry3: 0.015
4. Run 1 week with real money
5. **Goal**: Prove that live results match paper trading results

### Week 4+: Scale
- If weekly P&L is positive and consistent, increase lot sizes
- Expand to 2-3 pairs
- Monitor daily: hit target? respect stop? Scale accordingly

---

## Troubleshooting

### EA Doesn't Execute Orders
- [ ] Ensure account has minimum margin (usually 1% of position size)
- [ ] Check if leverage is sufficient (1:100 minimum recommended)
- [ ] Verify account is LIVE (not demo mode error)
- [ ] Check Terminal tab for error messages (usually shows why)

### Indicator Doesn't Display
- [ ] Recompile the indicator file (Tools → MetaEditor → Compile)
- [ ] Restart MT4
- [ ] Ensure indicator is attached to SAME chart as EA

### No Signals Generated
- [ ] Check if price is touching 20-day high/low (no signal = no trade setup)
- [ ] Check RSI (usually neutral except extremes <30 or >70)
- [ ] Check chart timeframe (default assumes 1-hour, adjust if using daily)

### Orders Not Closing at Stop Loss
- [ ] Increase Stop Loss parameter (some brokers require 10+ pips minimum)
- [ ] Check bid/ask spread (wide spreads can prevent stops)
- [ ] Verify EA has proper permissions (check Expert Advisors allowed in Options)

---

## Key Settings (What to Change)

### For Aggressive Trading (More risk, more reward):
```
LotSize_Entry1: 0.05 (instead of 0.01)
LotSize_Entry2: 0.10
LotSize_Entry3: 0.10
DailyTarget: 50.0 (instead of $10)
DailyStop: -20.0 (instead of -$5)
```

### For Conservative Trading (Less risk, steady growth):
```
LotSize_Entry1: 0.005
LotSize_Entry2: 0.015
LotSize_Entry3: 0.015
DailyTarget: 5.0 (instead of $10)
DailyStop: -2.0 (instead of -$5)
```

### For Different Pairs:
EA works on any forex pair. Test on:
- EURUSD (recommended, most liquid)
- GBPUSD (similar logic)
- AUDUSD (more volatile, wider stops needed)
- NZDUSD
- USDCAD

---

## What's Next

1. **Compile the files** (F5 in MetaEditor)
2. **Attach EA to demo chart** (practice account first)
3. **Attach indicator on same chart**
4. **Run for 3-5 days** (watch it trade)
5. **Review results** (did it follow the rules?)
6. **Paper trade 1 week** (no money at risk)
7. **Go live** ($100-500 starting capital)

---

## Performance Targets (What to Expect)

| Metric | Target |
|--------|--------|
| Win Rate | >50% (48% OK if 3-trade scalps) |
| Avg Win | +$1-2 per trade |
| Avg Loss | -$0.50-1 per loss |
| Daily Target | +$10 (2% of $500 account) |
| Daily Stop | -$5 (max loss/day) |
| Monthly Growth | 10-20% |

**Reality**: First month may be flat (learning curve). Month 2+ should show consistent growth.

---

## Support

**If something doesn't work:**
1. Check Terminal tab for error messages
2. Review architecture document (`NCI-EA-Indicator-Architecture.md`)
3. Check that files compiled without errors
4. Verify EA has sufficient margin
5. Test on demo account first

---

**Start trading. Track results. Adjust based on performance. Compound steady wins.**

The EA is ready. You're ready. Let's go.
