# NERDCOMMAND Trading Master v3.0 — Git Push Guide

## Ready to Push to GitHub

Your repo is complete and ready to commit. Follow these steps:

---

## Step 1: Start NCI_Bridge.py

Open terminal/CMD in your project folder and run:

```bash
python NCI_Bridge.py
```

Expected output:
```
NCI Bridge running on port 8080
Waiting for connections...
```

**Keep this running** (don't close the terminal).

---

## Step 2: Use Claude Code / Cowork to Push

Once the bridge is running, you can:

### Option A: Use Claude Code (Recommended)
1. Open Claude.ai
2. Click **Code** (bottom left)
3. Ask: "Initialize git repo and push NCI-Trading-Master-v3.0 to my GitHub"
4. It will:
   - Initialize local git repo
   - Add all files
   - Create initial commit
   - Push to GitHub

### Option B: Use Cowork (If Bridge is Running)
1. Open Claude.ai
2. Click **Cowork**
3. Select your project folder
4. Ask Claude to commit and push

### Option C: Manual Git Commands
If you prefer command line:

```bash
cd /path/to/nci-trading-repo

# Initialize repo (first time only)
git init

# Add files
git add .

# Commit
git commit -m "NCI Trading Master v3.0 - Merged EMA81320 + 4 Strategies + Engulfing"

# Add remote (replace with your actual repo URL)
git remote add origin https://github.com/chapmancapital1-droid/https-github.com-openclaw-openclaw.git

# Push
git push -u origin main
```

---

## What's Being Committed

### Files Included:
✅ `NCI_Trading_EA_MASTER_v3.0.mq4` (18KB)
- EMA81320 + 4 strategies + engulfing
- Triangle entry, unified stop, 3-trade scalps
- Daily limiter, session filter, H4 gate

✅ `NCI_Trading_Indicator_MASTER_v3.0.mq4` (13KB)
- Real-time dashboard
- Signal visualization
- Entry/stop display
- P&L tracking

✅ `README.md` (Complete guide)
- System overview
- Strategy breakdown
- Installation steps
- Configuration options
- Testing workflow
- Troubleshooting

✅ `.gitignore` (Repo cleanup)
- Excludes compiled files (.ex4/.ex5)
- Excludes Python cache
- Excludes IDE files
- Excludes backups

---

## What's NOT Committed (Excluded by .gitignore)

❌ Compiled files (.ex4, .ex5)
❌ __pycache__/ (Python cache)
❌ IDE files (.vscode/, .idea/)
❌ Backups and temp files
❌ Sensitive .env files

---

## After Push

### Verify on GitHub:
1. Go to your repo: https://github.com/chapmancapital1-droid/https-github.com-openclaw-openclaw
2. Check that files are there:
   - README.md
   - NCI_Trading_EA_MASTER_v3.0.mq4
   - NCI_Trading_Indicator_MASTER_v3.0.mq4
   - .gitignore

### Create Releases (Optional):
1. Click "Releases" on GitHub
2. Click "Create new release"
3. Tag: `v3.0`
4. Title: "NCI Trading Master v3.0 - Merged System"
5. Description: Copy from README.md

---

## Future Updates

After initial push, future commits are easy:

```bash
# Make changes to files

# Commit
git add .
git commit -m "Description of changes"

# Push
git push
```

---

## Troubleshooting

### "Bridge not running" error
- Make sure `NCI_Bridge.py` is running (step 1)
- Check the terminal running the bridge

### "Remote already exists" error
```bash
# Remove old remote
git remote remove origin

# Add correct one
git remote add origin https://github.com/chapmancapital1-droid/https-github.com-openclaw-openclaw.git
```

### "Authentication failed" error
- Make sure you're logged into GitHub via Claude Code
- Or use SSH keys (advanced)

---

## Current Repo Status

| Component | Status |
|-----------|--------|
| EA Code | ✅ Complete, Compiled |
| Indicator Code | ✅ Complete, Compiled |
| README | ✅ Complete |
| .gitignore | ✅ Ready |
| Version | v3.0 |
| Ready to Push | ✅ YES |

---

## Next Steps After Push

1. ✅ Verify files on GitHub
2. ✅ Compile both .mq4 files in MT4
3. ✅ Attach EA + Indicator to demo chart
4. ✅ Paper trade 1 week
5. ✅ Go live with $100-500
6. ✅ Compound 10-20% monthly

---

**Your repo is ready. Push when bridge is running.**

**Then start trading.**
