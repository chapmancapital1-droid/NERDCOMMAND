# NCI TRADING EA + INDICATOR — Architecture (MT4/MQL4)

## System Overview

```
INDICATOR (Visual layer)
├─ Displays all signals
├─ Shows entry/exit zones
├─ Plots stop loss levels
├─ Shows trade count
└─ Displays daily P&L

         ↓ (communicates via global variables)

EA (Execution layer)
├─ Signal Generator (4 strategies)
├─ Signal Fusion Engine
├─ Triangle Entry Executor
├─ Unified Stop Loss Manager
├─ 3-Trade Scalp Counter
├─ Daily Limiter
├─ Order Management
└─ Dashboard
```

---

## EA Architecture (MQL4)

### Component 1: Signal Generators (4 Strategies)

**Strategy 1: Breakout Trader**
```
Input: Current price, 20-day high/low, 50-day MA
Output: Signal (BUY/SELL/HOLD), Confidence (0.0-1.0)

Logic:
  if (Price > 20DayHigh) return (BUY, 0.8)
  if (Price < 20DayLow) return (SELL, 0.8)
  if (Close < 50DayMA) return (EXIT, 1.0)
  return (HOLD, 0)
```

**Strategy 2: Statistical Arbitrage (Pairs)**
```
Input: Pair1 (EURUSD) vs Pair2 (GBPUSD) correlation, spread
Output: Signal, Confidence

Logic:
  correlation = correlate(EURUSD_close, GBPUSD_close, 20 bars)
  spread = EURUSD - (GBPUSD * ratio)
  std_dev = stdev(spread, 20)
  
  if (spread > 2*std_dev) return (SELL, 0.9)
  if (spread < -2*std_dev) return (BUY, 0.9)
  if (spread between ±1*std_dev) return (EXIT, 1.0)
```

**Strategy 3: Crypto Mean Reversion (RSI)**
```
Input: RSI(14)
Output: Signal, Confidence

Logic:
  if (RSI < 30) return (BUY, 0.7)
  if (RSI > 70) return (SELL, 0.7)
  if (RSI == 50) return (EXIT, 1.0)
  return (HOLD, 0)
```

**Strategy 4: Pairs Trading (AAPL/MSFT style for forex)**
```
Input: Pair spread > 2 sigma
Output: Signal, Confidence

Logic:
  spread = Pair1 - Pair2_weighted
  std_dev = stdev(spread, 20)
  
  if (spread > 2*std_dev) return (MEAN_REVERT_SHORT, 0.85)
  if (spread < -2*std_dev) return (MEAN_REVERT_LONG, 0.85)
```

### Component 2: Signal Fusion Engine

```
Input: 4 signals with confidence scores
Output: Combined signal + position size

Logic:
  total_confidence = sum(all_strategy_confidences)
  
  if (total_confidence > 2.0):
    return (signal_direction, 0.07 lots, HIGH)
  elif (total_confidence > 1.0):
    return (signal_direction, 0.04 lots, MEDIUM)
  elif (total_confidence > 0.5):
    return (signal_direction, 0.01 lots, LOW)
  else:
    return (HOLD, 0, NONE)
```

### Component 3: Triangle Entry Executor

```
State Machine:
  IDLE → 
    Entry1 (0.01 lots) → 
      Wait for confirmation → 
        Entry2 (0.03 lots) →
          Wait for confirmation →
            Entry3 (0.03 lots) →
              FULL POSITION (0.07 lots)

Logic:
  if (signal_generated):
    OrderBuy(Symbol(), 0.01, Ask, 0, 0, "Entry1")
    entry_price = Ask
    entry_state = ENTRY1
    
  if (price moves in favor AND entry_state == ENTRY1):
    OrderBuy(Symbol(), 0.03, Ask, 0, 0, "Entry2")
    entry_state = ENTRY2
    
  if (price continues in favor AND entry_state == ENTRY2):
    OrderBuy(Symbol(), 0.03, Ask, 0, 0, "Entry3")
    entry_state = ENTRY3_FULL
    position_size = 0.07
```

### Component 4: Unified Dynamic Stop Loss

```
Global Variable: unified_stop_loss_price

Logic (every tick):
  atr = iATR(Symbol(), 0, 14, 0)
  stop_distance = atr * 2
  
  if (position_size > 0):
    new_stop = entry_price - stop_distance
    
    // Trail stop UP only (never DOWN)
    if (new_stop > unified_stop_loss_price):
      unified_stop_loss_price = new_stop
      UpdateOrders(unified_stop_loss_price)
    
    // Check if stop hit
    if ((Bid() <= unified_stop_loss_price AND direction == LONG) OR
        (Ask() >= unified_stop_loss_price AND direction == SHORT)):
      CloseAllPositions()
      position_size = 0
      entry_state = IDLE
```

### Component 5: 3-Trade Scalp Exit Counter

```
Global Variable: scalp_wins_count = 0

Logic (after each micro-win):
  if (price +10 pips from entry):
    scalp_wins_count++
    
  if (scalp_wins_count >= 3):
    CloseAllPositions()
    ResetTradeState()
    scalp_wins_count = 0
    daily_pnl += position_pnl
```

### Component 6: Daily P&L Limiter

```
Global Variables: 
  daily_pnl = 0
  daily_target = 10 (dollars)
  daily_stop = -5 (dollars)

Logic (every tick):
  daily_pnl = calculate_all_open_positions_pnl()
  
  if (daily_pnl >= daily_target):
    ReducePositionSize(0.5)  // Close 50% of position
    Alert("Daily target hit! Reduce risk.")
    
  if (daily_pnl <= daily_stop):
    CloseAllPositions()
    trading_disabled_today = true
    Alert("Daily stop hit! No more trades today.")
```

### Component 7: Order Management

```
Functions:
  - OpenPosition(symbol, direction, size, entry_price)
  - ClosePosition(ticket, exit_price)
  - UpdateStopLoss(ticket, new_stop)
  - GetOpenPositionSize()
  - GetOpenPositionPnL()
  - GetPositionEntryPrice()
```

### Component 8: Dashboard

```
Display (on chart):
  ┌─────────────────────────────┐
  │ NCI TRADING EA - LIVE       │
  ├─────────────────────────────┤
  │ Position: 0.07 lots (LONG)  │
  │ Entry: 1.0500               │
  │ Stop: 1.0400 (-100 pips)    │
  │ Current: 1.0510 (+10 pips)  │
  │ Open P&L: +$0.70            │
  │                             │
  │ Scalp Wins: 2/3             │
  │ Daily P&L: +$3.50 / +$10    │
  │ Daily Stop: -$5.00          │
  │                             │
  │ Breakout: BUY (1.0x)        │
  │ Stat Arb: HOLD              │
  │ RSI: SELL (0.8x)            │
  │ Pairs: HOLD                 │
  │ ─────────────────────────── │
  │ Fusion: MEDIUM (+$0.04)     │
  └─────────────────────────────┘
```

---

## Indicator Architecture (MQL4)

### Visual Display Layers

**Layer 1: Breakout Levels**
```
Draw:
  - 20-day high (blue line)
  - 20-day low (red line)
  - 50-day MA (yellow line)
  - Entry price (green dot)
```

**Layer 2: Stop Loss & Target**
```
Draw:
  - Stop loss line (red dashed)
  - Trail stop current (red moving)
  - Profit target zones (green shaded)
```

**Layer 3: Signal Visualizations**
```
Display:
  - Breakout arrow (up/down)
  - RSI oversold/overbought zones (shaded)
  - ATR-based stop distance
  - Correlation divergence indicator
```

**Layer 4: Trade Metrics**
```
Text boxes:
  - Current signal strengths (4 strategies)
  - Fusion signal (high/medium/low)
  - Position size (0.01/0.04/0.07)
  - Entry #1, #2, #3 status
  - Scalp count (0/1/2/3)
  - Daily P&L vs limits
```

---

## Data Flow

```
Market Tick
  ↓
Indicator Updates
  ├─ Recalculate all indicators (20-day high, RSI, ATR, etc.)
  ├─ Store in global variables
  └─ Paint visual layers
  ↓
EA Reads Global Variables
  ├─ Get latest signals
  ├─ Fusion + position sizing
  ├─ Execute entry/exit logic
  ├─ Check daily limits
  └─ Update dashboard
  ↓
Orders Sent to Broker
  ├─ Entry orders (triangle)
  ├─ Stop loss updates
  └─ Exit orders (3-trade scalps)
```

---

## Files to Create

1. **NCI_Trading_EA_v1.mq4** (500-700 lines)
   - Main EA logic
   - All 4 strategy functions
   - Signal fusion
   - Order management
   - Dashboard display

2. **NCI_Trading_Indicator_v1.mq4** (300-400 lines)
   - Visual layers
   - Global variable updates
   - Real-time chart painting

---

## Implementation Order

1. **Week 1**: Build signal generators (4 strategies)
2. **Week 1-2**: Build signal fusion + triangle entry
3. **Week 2**: Build stop loss manager + scalp counter
4. **Week 2**: Build daily limiter + order management
5. **Week 3**: Build indicator (visual layer)
6. **Week 3**: Build EA dashboard
7. **Week 3-4**: Paper test (1 week)
8. **Week 4+**: Live trade

---

## Testing Checklist

- [ ] Each signal generator returns correct signals
- [ ] Fusion engine combines signals correctly
- [ ] Triangle entry executes in sequence
- [ ] Stop loss trails properly
- [ ] 3-trade scalp counter works
- [ ] Daily limits enforce correctly
- [ ] Indicator displays all signals
- [ ] Dashboard updates in real-time
- [ ] Paper trading 1 week (match signals)
- [ ] Live trading $100-500 account

---

Ready to code?
