//+------------------------------------------------------------------+
//|                    NCI_Trading_Indicator_v1.mq4                  |
//|              NERDCOMMAND Core Intelligence Trading Indicator      |
//|          Visual companion: Shows all signals, stops, P&L          |
//+------------------------------------------------------------------+

#property strict
#property indicator_chart_window
#property copyright "NERDCOMMAND"
#property version   "1.0"

// Input parameters
input color Color_Entry = clrGreen;
input color Color_Stop = clrRed;
input color Color_MA20 = clrBlue;
input color Color_MA50 = clrYellow;
input color Color_ATR = clrGray;
input int Font_Size = 11;
input string Font_Name = "Arial";

int MA20_Period = 20;
int MA50_Period = 50;
int ATR_Period = 14;
int RSI_Period = 14;

//+------------------------------------------------------------------+
//| Indicator initialization function                                |
//+------------------------------------------------------------------+
int OnInit() {
    SetIndexLabel(0, "NCI Trading Indicator");
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Indicator deinitialization function                              |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
    // Clean up objects
    ObjectsDeleteAll(ChartID(), "NCI_");
}

//+------------------------------------------------------------------+
//| Indicator iteration function                                     |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    
    // Draw support/resistance levels
    DrawSupportResistance();
    
    // Draw moving averages
    DrawMovingAverages();
    
    // Draw ATR stop distance
    DrawATRLines();
    
    // Draw dashboard
    DrawDashboard();
    
    // Draw signal visualization
    DrawSignalInfo();
    
    return rates_total;
}

//+------------------------------------------------------------------+
//| Draw Support/Resistance (20-day high/low)                         |
//+------------------------------------------------------------------+
void DrawSupportResistance() {
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA20_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA20_Period, 0));
    
    // Get bar time for drawing
    datetime current_time = Time[0];
    datetime time_back = TimeCurrent() - 20 * 86400;
    
    // Draw resistance (20-day high)
    ObjectCreate(ChartID(), "NCI_Resistance", OBJ_HLINE, 0, 0, high20);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_COLOR, clrBlue);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_STYLE, STYLE_SOLID);
    
    // Draw support (20-day low)
    ObjectCreate(ChartID(), "NCI_Support", OBJ_HLINE, 0, 0, low20);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_COLOR, clrRed);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_STYLE, STYLE_SOLID);
    
    // Labels
    ObjectCreate(ChartID(), "NCI_Resist_Label", OBJ_TEXT, 0, current_time, high20);
    ObjectSetString(ChartID(), "NCI_Resist_Label", OBJPROP_TEXT, "Resistance (20H)");
    ObjectSetInteger(ChartID(), "NCI_Resist_Label", OBJPROP_COLOR, clrBlue);
    ObjectSetInteger(ChartID(), "NCI_Resist_Label", OBJPROP_FONTSIZE, Font_Size);
    
    ObjectCreate(ChartID(), "NCI_Support_Label", OBJ_TEXT, 0, current_time, low20);
    ObjectSetString(ChartID(), "NCI_Support_Label", OBJPROP_TEXT, "Support (20L)");
    ObjectSetInteger(ChartID(), "NCI_Support_Label", OBJPROP_COLOR, clrRed);
    ObjectSetInteger(ChartID(), "NCI_Support_Label", OBJPROP_FONTSIZE, Font_Size);
}

//+------------------------------------------------------------------+
//| Draw Moving Averages                                              |
//+------------------------------------------------------------------+
void DrawMovingAverages() {
    double ma20 = iMA(Symbol(), 0, MA20_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    
    datetime current_time = Time[0];
    
    // Draw MA20 line
    ObjectCreate(ChartID(), "NCI_MA20", OBJ_HLINE, 0, 0, ma20);
    ObjectSetInteger(ChartID(), "NCI_MA20", OBJPROP_COLOR, Color_MA20);
    ObjectSetInteger(ChartID(), "NCI_MA20", OBJPROP_WIDTH, 1);
    ObjectSetInteger(ChartID(), "NCI_MA20", OBJPROP_STYLE, STYLE_DOT);
    
    // Draw MA50 line
    ObjectCreate(ChartID(), "NCI_MA50", OBJ_HLINE, 0, 0, ma50);
    ObjectSetInteger(ChartID(), "NCI_MA50", OBJPROP_COLOR, Color_MA50);
    ObjectSetInteger(ChartID(), "NCI_MA50", OBJPROP_WIDTH, 1);
    ObjectSetInteger(ChartID(), "NCI_MA50", OBJPROP_STYLE, STYLE_DOT);
}

//+------------------------------------------------------------------+
//| Draw ATR-Based Stop Distance                                      |
//+------------------------------------------------------------------+
void DrawATRLines() {
    double entry_price = GlobalVariableGet("NCI_Entry_Price");
    double stop_loss = GlobalVariableGet("NCI_Stop_Loss");
    
    if (entry_price == 0) return; // No position
    
    datetime current_time = Time[0];
    
    // Draw entry price line
    ObjectCreate(ChartID(), "NCI_Entry_Line", OBJ_HLINE, 0, 0, entry_price);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_COLOR, Color_Entry);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_STYLE, STYLE_SOLID);
    
    // Draw stop loss line
    ObjectCreate(ChartID(), "NCI_Stop_Line", OBJ_HLINE, 0, 0, stop_loss);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_COLOR, Color_Stop);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_STYLE, STYLE_DASH);
    
    // Draw entry box
    ObjectCreate(ChartID(), "NCI_Entry_Label", OBJ_TEXT, 0, current_time, entry_price);
    ObjectSetString(ChartID(), "NCI_Entry_Label", OBJPROP_TEXT, "Entry: " + DoubleToStr(entry_price, 5));
    ObjectSetInteger(ChartID(), "NCI_Entry_Label", OBJPROP_COLOR, Color_Entry);
    ObjectSetInteger(ChartID(), "NCI_Entry_Label", OBJPROP_FONTSIZE, Font_Size);
    
    // Draw stop loss label
    ObjectCreate(ChartID(), "NCI_Stop_Label", OBJ_TEXT, 0, current_time, stop_loss);
    ObjectSetString(ChartID(), "NCI_Stop_Label", OBJPROP_TEXT, "Stop: " + DoubleToStr(stop_loss, 5));
    ObjectSetInteger(ChartID(), "NCI_Stop_Label", OBJPROP_COLOR, Color_Stop);
    ObjectSetInteger(ChartID(), "NCI_Stop_Label", OBJPROP_FONTSIZE, Font_Size);
}

//+------------------------------------------------------------------+
//| Draw Dashboard (Main Info Panel)                                  |
//+------------------------------------------------------------------+
void DrawDashboard() {
    double entry_price = GlobalVariableGet("NCI_Entry_Price");
    int entry_stage = (int)GlobalVariableGet("NCI_Entry_Stage");
    int scalp_wins = (int)GlobalVariableGet("NCI_Scalp_Count");
    double daily_pnl = GlobalVariableGet("NCI_Daily_PnL");
    double stop_loss = GlobalVariableGet("NCI_Stop_Loss");
    
    double current_price = Close[0];
    double current_pnl = 0;
    
    if (entry_price > 0) {
        current_pnl = current_price - entry_price;
    }
    
    // Main dashboard box
    int x_offset = 10;
    int y_offset = 30;
    int line_height = 20;
    
    // Title
    DrawText("NCI TRADING EA - LIVE", x_offset, y_offset, clrWhite, Font_Size, "Arial Black");
    y_offset += line_height * 2;
    
    // Position info
    string position_text = "";
    if (entry_stage == 0) {
        position_text = "Position: IDLE";
    } else if (entry_stage == 1) {
        position_text = "Position: 0.01 lots (Entry1)";
    } else if (entry_stage == 2) {
        position_text = "Position: 0.04 lots (Entry2)";
    } else if (entry_stage == 3) {
        position_text = "Position: 0.07 lots (FULL)";
    }
    DrawText(position_text, x_offset, y_offset, clrYellow, Font_Size, Font_Name);
    y_offset += line_height;
    
    // Entry price
    if (entry_price > 0) {
        DrawText("Entry: " + DoubleToStr(entry_price, 5), x_offset, y_offset, Color_Entry, Font_Size, Font_Name);
        y_offset += line_height;
        
        // Current price & P&L
        DrawText("Current: " + DoubleToStr(current_price, 5) + " (P&L: " + DoubleToStr(current_pnl * 10000, 0) + " pips)", 
                 x_offset, y_offset, clrLime, Font_Size, Font_Name);
        y_offset += line_height;
        
        // Stop loss
        DrawText("Stop: " + DoubleToStr(stop_loss, 5), x_offset, y_offset, Color_Stop, Font_Size, Font_Name);
        y_offset += line_height;
        
        // Scalp wins
        DrawText("Scalp Wins: " + IntegerToString(scalp_wins) + "/3", x_offset, y_offset, clrMagenta, Font_Size, Font_Name);
        y_offset += line_height;
    }
    
    y_offset += line_height;
    
    // Daily P&L
    color pnl_color = clrRed;
    if (daily_pnl >= 0) pnl_color = clrLime;
    
    DrawText("Daily P&L: $" + DoubleToStr(daily_pnl, 2) + " / Target: $10 / Stop: -$5", 
             x_offset, y_offset, pnl_color, Font_Size, Font_Name);
}

//+------------------------------------------------------------------+
//| Draw Signal Info (4 Strategies)                                   |
//+------------------------------------------------------------------+
void DrawSignalInfo() {
    // Calculate signals
    double rsi = iRSI(Symbol(), 0, RSI_Period, PRICE_CLOSE, 0);
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA20_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA20_Period, 0));
    
    int x_offset = 10;
    int y_offset = 250;
    
    // Title
    DrawText("=== STRATEGY SIGNALS ===", x_offset, y_offset, clrWhite, Font_Size, "Arial Black");
    y_offset += 20;
    
    // Breakout
    string breakout_text = "Breakout: ";
    color breakout_color = clrGray;
    if (Close[0] > high20) {
        breakout_text += "BUY (1.0x)";
        breakout_color = clrGreen;
    } else if (Close[0] < low20) {
        breakout_text += "SELL (1.0x)";
        breakout_color = clrRed;
    } else if (Close[0] < ma50) {
        breakout_text += "EXIT";
        breakout_color = clrOrange;
    } else {
        breakout_text += "HOLD";
    }
    DrawText(breakout_text, x_offset, y_offset, breakout_color, Font_Size, Font_Name);
    y_offset += 20;
    
    // RSI
    string rsi_text = "RSI: ";
    color rsi_color = clrGray;
    if (rsi < 30) {
        rsi_text += "OVERSOLD - BUY (0.8x)";
        rsi_color = clrGreen;
    } else if (rsi > 70) {
        rsi_text += "OVERBOUGHT - SELL (0.8x)";
        rsi_color = clrRed;
    } else {
        rsi_text += "NEUTRAL";
    }
    DrawText(rsi_text + " RSI=" + DoubleToStr(rsi, 1), x_offset, y_offset, rsi_color, Font_Size, Font_Name);
    y_offset += 20;
    
    // MA Divergence
    string ma_text = "MA Divergence: ";
    color ma_color = clrGray;
    double deviation = MathAbs(Close[0] - ma50) / ma50 * 100;
    if (deviation > 2) {
        ma_text += "DIVERGED (Mean Revert " + (Close[0] > ma50 ? "SELL" : "BUY") + ") (1.2x)";
        ma_color = (Close[0] > ma50) ? clrRed : clrGreen;
    } else {
        ma_text += "NORMAL";
    }
    DrawText(ma_text, x_offset, y_offset, ma_color, Font_Size, Font_Name);
}

//+------------------------------------------------------------------+
//| Draw Text Helper                                                  |
//+------------------------------------------------------------------+
void DrawText(string text, int x, int y, color clr, int font_size, string font_name) {
    static int counter = 0;
    string obj_name = "NCI_Text_" + IntegerToString(counter++);
    
    ObjectCreate(ChartID(), obj_name, OBJ_LABEL, 0, 0, 0);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_XDISTANCE, x);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_YDISTANCE, y);
    ObjectSetString(ChartID(), obj_name, OBJPROP_TEXT, text);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_COLOR, clr);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_FONTSIZE, font_size);
    ObjectSetString(ChartID(), obj_name, OBJPROP_FONT, font_name);
}

//+------------------------------------------------------------------+
