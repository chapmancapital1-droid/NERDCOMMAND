//+------------------------------------------------------------------+
//|                         NCI_Trading_EA_v1.mq4                    |
//|                  NERDCOMMAND Core Intelligence Trading            |
//|              4 Strategies | Triangle Entry | Unified Stop        |
//+------------------------------------------------------------------+

#property strict
#property copyright "NERDCOMMAND"
#property version   "1.0"
#property description "Auto-Trading EA: Breakout, Stat Arb, Mean Reversion, Pairs"

// Input parameters
input double LotSize_Entry1 = 0.01;      // Entry 1 lot size
input double LotSize_Entry2 = 0.03;      // Entry 2 lot size
input double LotSize_Entry3 = 0.03;      // Entry 3 lot size
input int ATR_Period = 14;               // ATR period for stop loss
input double ATR_Multiplier = 2.0;       // ATR multiplier for stop distance
input double DailyTarget = 10.0;         // Daily profit target ($)
input double DailyStop = -5.0;           // Daily loss stop ($)
input int MA20_Period = 20;              // 20-day MA
input int MA50_Period = 50;              // 50-day MA
input int RSI_Period = 14;               // RSI period
input int Correlation_Period = 20;       // Correlation period

// Global trading state
double entry_price = 0;
double unified_stop_loss = 0;
int entry_stage = 0;                     // 0=IDLE, 1=ENTRY1, 2=ENTRY2, 3=FULL
int trade_direction = 0;                 // 1=LONG, -1=SHORT, 0=NONE
int scalp_wins_count = 0;
double daily_pnl = 0;
bool trading_disabled_today = false;
datetime last_trading_day = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit() {
    Print("NCI Trading EA v1.0 initialized");
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
    Print("NCI Trading EA deinitialized");
}

//+------------------------------------------------------------------+
//| Expert tick function (main loop)                                 |
//+------------------------------------------------------------------+
void OnTick() {
    // Reset daily values at midnight
    ResetDailyVariables();
    
    // Calculate daily P&L
    daily_pnl = CalculateDailyPnL();
    
    // Check daily limits
    if (daily_pnl >= DailyTarget) {
        ReducePositionSize();
        return;
    }
    if (daily_pnl <= DailyStop) {
        CloseAllPositions();
        trading_disabled_today = true;
        Alert("Daily stop hit! Trading disabled for today.");
        return;
    }
    
    // Skip if already full position
    if (entry_stage == 3) {
        ManageOpenPosition();
        return;
    }
    
    // Generate signals from 4 strategies
    double signal_breakout, conf_breakout;
    double signal_stat_arb, conf_stat_arb;
    double signal_rsi, conf_rsi;
    double signal_pairs, conf_pairs;
    
    GetBreakoutSignal(signal_breakout, conf_breakout);
    GetStatArbSignal(signal_stat_arb, conf_stat_arb);
    GetRSISignal(signal_rsi, conf_rsi);
    GetPairsSignal(signal_pairs, conf_pairs);
    
    // Fuse signals
    double total_confidence = 0;
    int fused_signal = FuseSignals(signal_breakout, conf_breakout,
                                    signal_stat_arb, conf_stat_arb,
                                    signal_rsi, conf_rsi,
                                    signal_pairs, conf_pairs,
                                    total_confidence);
    
    // Execute entries based on stage
    if (fused_signal != 0 && entry_stage == 0) {
        Entry_Stage1(fused_signal);
    }
    else if (entry_stage == 1 && PriceMovingInOurFavor(fused_signal)) {
        Entry_Stage2(fused_signal);
    }
    else if (entry_stage == 2 && PriceMovingInOurFavor(fused_signal)) {
        Entry_Stage3(fused_signal);
    }
    
    // Manage open positions (stop loss, scalp exit)
    if (entry_stage > 0) {
        ManageOpenPosition();
    }
    
    // Update global variables for indicator
    GlobalVariableSet("NCI_Entry_Price", entry_price);
    GlobalVariableSet("NCI_Stop_Loss", unified_stop_loss);
    GlobalVariableSet("NCI_Entry_Stage", entry_stage);
    GlobalVariableSet("NCI_Scalp_Count", scalp_wins_count);
    GlobalVariableSet("NCI_Daily_PnL", daily_pnl);
}

//+------------------------------------------------------------------+
//| Strategy 1: Breakout Trader (20-day high/low)                   |
//+------------------------------------------------------------------+
void GetBreakoutSignal(double &signal, double &confidence) {
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA20_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA20_Period, 0));
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    
    double current_close = Close[0];
    
    if (current_close > high20) {
        signal = 1;  // BUY
        confidence = 0.8;
    }
    else if (current_close < low20) {
        signal = -1; // SELL
        confidence = 0.8;
    }
    else if (current_close < ma50) {
        signal = 0;  // EXIT
        confidence = 1.0;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| Strategy 2: Statistical Arbitrage (simplified for forex)         |
//+------------------------------------------------------------------+
void GetStatArbSignal(double &signal, double &confidence) {
    // Simplified: use price deviation from MA50
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    double deviation = MathAbs(Close[0] - ma50) / ma50 * 100;
    
    if (deviation > 2) {
        // Price diverged from MA, mean revert
        if (Close[0] > ma50) {
            signal = -1; // SELL (price too high)
        } else {
            signal = 1;  // BUY (price too low)
        }
        confidence = 0.9;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| Strategy 3: Mean Reversion (RSI)                                 |
//+------------------------------------------------------------------+
void GetRSISignal(double &signal, double &confidence) {
    double rsi = iRSI(Symbol(), 0, RSI_Period, PRICE_CLOSE, 0);
    
    if (rsi < 30) {
        signal = 1;      // BUY (oversold)
        confidence = 0.7;
    }
    else if (rsi > 70) {
        signal = -1;     // SELL (overbought)
        confidence = 0.7;
    }
    else if (rsi == 50) {
        signal = 0;      // EXIT
        confidence = 1.0;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| Strategy 4: Pairs Trading (simplified)                           |
//+------------------------------------------------------------------+
void GetPairsSignal(double &signal, double &confidence) {
    // Simplified: use close > open pattern
    double close_current = Close[0];
    double open_current = Open[0];
    double high_current = High[0];
    double low_current = Low[0];
    
    // Engulfing pattern check
    if (close_current > open_current && 
        open_current < Low[1] && 
        close_current > High[1]) {
        signal = 1;      // BUY (bullish engulfing)
        confidence = 0.85;
    }
    else if (close_current < open_current && 
             open_current > High[1] && 
             close_current < Low[1]) {
        signal = -1;     // SELL (bearish engulfing)
        confidence = 0.85;
    }
    else {
        signal = 0;
        confidence = 0;
    }
}

//+------------------------------------------------------------------+
//| Signal Fusion Engine                                              |
//+------------------------------------------------------------------+
int FuseSignals(double s1, double c1,
                double s2, double c2,
                double s3, double c3,
                double s4, double c4,
                double &total_conf) {
    
    // Weight confidence scores
    double weighted_conf = 0;
    int signal_direction = 0;
    
    if (s1 != 0) {
        weighted_conf += c1 * 1.0;
        if (signal_direction == 0) signal_direction = (int)s1;
    }
    if (s2 != 0) {
        weighted_conf += c2 * 1.2;  // Stat Arb is more reliable
        if (signal_direction == 0) signal_direction = (int)s2;
    }
    if (s3 != 0) {
        weighted_conf += c3 * 0.8;  // RSI is noisier
        if (signal_direction == 0) signal_direction = (int)s3;
    }
    if (s4 != 0) {
        weighted_conf += c4 * 1.1;
        if (signal_direction == 0) signal_direction = (int)s4;
    }
    
    total_conf = weighted_conf;
    
    // Position sizing based on confidence
    if (weighted_conf > 2.0) {
        // HIGH conviction
        return signal_direction;
    }
    else if (weighted_conf > 1.0) {
        // MEDIUM conviction (still trade)
        return signal_direction;
    }
    else if (weighted_conf > 0.5) {
        // LOW conviction (skip or minimal)
        return 0;
    }
    else {
        return 0;
    }
}

//+------------------------------------------------------------------+
//| Entry Stage 1 (0.01 lots)                                         |
//+------------------------------------------------------------------+
void Entry_Stage1(int direction) {
    trade_direction = direction;
    entry_price = Ask;
    
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry1, Ask, 2, 0, 0, "Entry1", 0, 0, clrGreen);
    }
    else if (direction == -1) {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry1, Bid, 2, 0, 0, "Entry1", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 1;
        Print("Entry Stage 1 executed at ", entry_price);
    }
}

//+------------------------------------------------------------------+
//| Entry Stage 2 (0.01 + 0.03 = 0.04 lots)                          |
//+------------------------------------------------------------------+
void Entry_Stage2(int direction) {
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry2, Ask, 2, 0, 0, "Entry2", 0, 0, clrGreen);
    }
    else {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry2, Bid, 2, 0, 0, "Entry2", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 2;
        Print("Entry Stage 2 executed at ", Ask);
    }
}

//+------------------------------------------------------------------+
//| Entry Stage 3 (0.01 + 0.03 + 0.03 = 0.07 lots FULL)              |
//+------------------------------------------------------------------+
void Entry_Stage3(int direction) {
    double ticket = 0;
    if (direction == 1) {
        ticket = OrderSend(Symbol(), OP_BUY, LotSize_Entry3, Ask, 2, 0, 0, "Entry3", 0, 0, clrGreen);
    }
    else {
        ticket = OrderSend(Symbol(), OP_SELL, LotSize_Entry3, Bid, 2, 0, 0, "Entry3", 0, 0, clrRed);
    }
    
    if (ticket > 0) {
        entry_stage = 3;
        Print("Entry Stage 3 (FULL 0.07) executed at ", Ask);
        
        // Set unified stop loss
        double atr = iATR(Symbol(), 0, ATR_Period, 0);
        double stop_distance = atr * ATR_Multiplier;
        
        if (trade_direction == 1) {
            unified_stop_loss = entry_price - stop_distance;
        } else {
            unified_stop_loss = entry_price + stop_distance;
        }
    }
}

//+------------------------------------------------------------------+
//| Manage Open Positions (stop loss, scalp exit)                    |
//+------------------------------------------------------------------+
void ManageOpenPosition() {
    // Update trailing stop loss
    double atr = iATR(Symbol(), 0, ATR_Period, 0);
    double stop_distance = atr * ATR_Multiplier;
    
    if (trade_direction == 1) {
        // LONG position
        double new_stop = Close[0] - stop_distance;
        if (new_stop > unified_stop_loss) {
            unified_stop_loss = new_stop;
        }
        
        // Check stop hit
        if (Bid < unified_stop_loss) {
            CloseAllPositions();
            Print("Stop loss hit (LONG)");
            return;
        }
    }
    else if (trade_direction == -1) {
        // SHORT position
        double new_stop = Close[0] + stop_distance;
        if (new_stop < unified_stop_loss) {
            unified_stop_loss = new_stop;
        }
        
        // Check stop hit
        if (Ask > unified_stop_loss) {
            CloseAllPositions();
            Print("Stop loss hit (SHORT)");
            return;
        }
    }
    
    // Check for 3-trade scalp exit
    CheckScalpExit();
}

//+------------------------------------------------------------------+
//| Check 3-Trade Scalp Exit                                          |
//+------------------------------------------------------------------+
void CheckScalpExit() {
    // Simplified: check if +10 pips profit
    double pnl = 0;
    
    if (trade_direction == 1) {
        pnl = (Close[0] - entry_price) * 100000; // pips for 1 micro lot
    }
    else if (trade_direction == -1) {
        pnl = (entry_price - Close[0]) * 100000;
    }
    
    // Every 10 pips, increment win counter
    if (pnl >= 10) {
        scalp_wins_count++;
        Print("Scalp win #", scalp_wins_count, " at +", pnl, " pips");
        
        if (scalp_wins_count >= 3) {
            CloseAllPositions();
            Print("3-Trade scalp target hit! Exiting all positions.");
            scalp_wins_count = 0;
            entry_stage = 0;
            trade_direction = 0;
        }
    }
}

//+------------------------------------------------------------------+
//| Price Moving In Our Favor                                         |
//+------------------------------------------------------------------+
bool PriceMovingInOurFavor(int direction) {
    if (direction == 1 && Close[0] > entry_price) {
        return true; // Price up from entry (LONG winning)
    }
    else if (direction == -1 && Close[0] < entry_price) {
        return true; // Price down from entry (SHORT winning)
    }
    return false;
}

//+------------------------------------------------------------------+
//| Close All Positions                                               |
//+------------------------------------------------------------------+
void CloseAllPositions() {
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                if (OrderType() == OP_BUY) {
                    OrderClose(OrderTicket(), OrderOpenPrice(), Bid, 2, clrRed);
                }
                else if (OrderType() == OP_SELL) {
                    OrderClose(OrderTicket(), OrderOpenPrice(), Ask, 2, clrGreen);
                }
            }
        }
    }
    entry_stage = 0;
    trade_direction = 0;
    scalp_wins_count = 0;
}

//+------------------------------------------------------------------+
//| Reduce Position Size (daily target hit)                          |
//+------------------------------------------------------------------+
void ReducePositionSize() {
    // Close 50% of open positions
    int position_count = 0;
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                position_count++;
            }
        }
    }
    
    if (position_count > 1) {
        // Close alternate orders
        int count = 0;
        for (int i = OrdersTotal() - 1; i >= 0; i--) {
            if (OrderSelect(i, SELECT_BY_POS)) {
                if (OrderSymbol() == Symbol()) {
                    count++;
                    if (count % 2 == 0) {
                        if (OrderType() == OP_BUY) {
                            OrderClose(OrderTicket(), OrderOpenPrice(), Bid, 2, clrOrange);
                        }
                        else {
                            OrderClose(OrderTicket(), OrderOpenPrice(), Ask, 2, clrOrange);
                        }
                    }
                }
            }
        }
    }
    Alert("Daily target hit! Position size reduced.");
}

//+------------------------------------------------------------------+
//| Calculate Daily P&L                                               |
//+------------------------------------------------------------------+
double CalculateDailyPnL() {
    double total_pnl = 0;
    
    for (int i = OrdersTotal() - 1; i >= 0; i--) {
        if (OrderSelect(i, SELECT_BY_POS)) {
            if (OrderSymbol() == Symbol()) {
                if (OrderType() == OP_BUY) {
                    total_pnl += (Bid - OrderOpenPrice()) * OrderOpenPrice() * OrderOpenPrice();
                }
                else if (OrderType() == OP_SELL) {
                    total_pnl += (OrderOpenPrice() - Ask) * OrderOpenPrice() * OrderOpenPrice();
                }
            }
        }
    }
    
    return total_pnl;
}

//+------------------------------------------------------------------+
//| Reset Daily Variables                                             |
//+------------------------------------------------------------------+
void ResetDailyVariables() {
    datetime current_time = TimeCurrent();
    datetime current_day = StrToTime(TimeToStr(current_time, TIME_DATE));
    
    if (current_day != last_trading_day) {
        last_trading_day = current_day;
        daily_pnl = 0;
        trading_disabled_today = false;
        scalp_wins_count = 0;
    }
}

//+------------------------------------------------------------------+
