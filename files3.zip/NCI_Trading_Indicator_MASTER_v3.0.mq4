//+------------------------------------------------------------------+
//|              NCI_Trading_Indicator_MASTER_v3.0.mq4               |
//|            NERDCOMMAND Core Intelligence Indicator               |
//|    Master Indicator: EMA Ribbon + 4 Strategies + Dashboard       |
//+------------------------------------------------------------------+

#property strict
#property indicator_chart_window
#property copyright "NERDCOMMAND"
#property version   "3.0"

// Input parameters
input color Color_Entry = clrGreen;
input color Color_Stop = clrRed;
input color Color_EMA8 = clrCyan;
input color Color_EMA13 = clrYellow;
input color Color_EMA20 = clrOrange;
input color Color_MA50 = clrMagenta;
input int Font_Size = 11;
input string Font_Name = "Arial";

int EMA8_Period = 8;
int EMA13_Period = 13;
int EMA20_Period = 20;
int MA50_Period = 50;
int RSI_Period = 14;
int ATR_Period = 14;

//+------------------------------------------------------------------+
//| Indicator initialization                                          |
//+------------------------------------------------------------------+
int OnInit() {
    SetIndexLabel(0, "NCI Trading Indicator MASTER v3.0");
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Indicator deinitialization                                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
    ObjectsDeleteAll(ChartID(), "NCI_");
}

//+------------------------------------------------------------------+
//| Indicator calculation function                                   |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    
    // Draw EMA ribbon (primary gate)
    DrawEMA_Ribbon();
    
    // Draw support/resistance
    DrawSupportResistance();
    
    // Draw entry/stop levels
    DrawEntryStopLevels();
    
    // Draw main dashboard
    DrawMainDashboard();
    
    // Draw strategy signals
    DrawStrategySignals();
    
    return rates_total;
}

//+------------------------------------------------------------------+
//| DRAW EMA RIBBON (8/13/20 - Primary Gate)                          |
//+------------------------------------------------------------------+
void DrawEMA_Ribbon() {
    double ema8 = iMA(Symbol(), 0, EMA8_Period, 0, MODE_EMA, PRICE_CLOSE, 0);
    double ema13 = iMA(Symbol(), 0, EMA13_Period, 0, MODE_EMA, PRICE_CLOSE, 0);
    double ema20 = iMA(Symbol(), 0, EMA20_Period, 0, MODE_EMA, PRICE_CLOSE, 0);
    
    datetime current_time = Time[0];
    
    // EMA8 (fast, cyan)
    ObjectCreate(ChartID(), "NCI_EMA8", OBJ_HLINE, 0, 0, ema8);
    ObjectSetInteger(ChartID(), "NCI_EMA8", OBJPROP_COLOR, Color_EMA8);
    ObjectSetInteger(ChartID(), "NCI_EMA8", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_EMA8", OBJPROP_STYLE, STYLE_SOLID);
    
    // EMA13 (medium, yellow)
    ObjectCreate(ChartID(), "NCI_EMA13", OBJ_HLINE, 0, 0, ema13);
    ObjectSetInteger(ChartID(), "NCI_EMA13", OBJPROP_COLOR, Color_EMA13);
    ObjectSetInteger(ChartID(), "NCI_EMA13", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_EMA13", OBJPROP_STYLE, STYLE_SOLID);
    
    // EMA20 (slow, orange)
    ObjectCreate(ChartID(), "NCI_EMA20", OBJ_HLINE, 0, 0, ema20);
    ObjectSetInteger(ChartID(), "NCI_EMA20", OBJPROP_COLOR, Color_EMA20);
    ObjectSetInteger(ChartID(), "NCI_EMA20", OBJPROP_WIDTH, 2);
    ObjectSetInteger(ChartID(), "NCI_EMA20", OBJPROP_STYLE, STYLE_SOLID);
    
    // Label: EMA Ribbon Status
    string ema_status = "EMAs: ";
    if (ema8 > ema13 && ema13 > ema20) {
        ema_status += "UPTREND (8>13>20)";
    } else if (ema8 < ema13 && ema13 < ema20) {
        ema_status += "DOWNTREND (8<13<20)";
    } else {
        ema_status += "MIXED";
    }
    
    DrawText(ema_status, 10, 350, clrLime, 12, "Arial Black");
}

//+------------------------------------------------------------------+
//| DRAW SUPPORT/RESISTANCE (20-day levels)                           |
//+------------------------------------------------------------------+
void DrawSupportResistance() {
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA50_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA50_Period, 0));
    
    // Resistance
    ObjectCreate(ChartID(), "NCI_Resistance", OBJ_HLINE, 0, 0, high20);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_COLOR, clrRed);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_WIDTH, 1);
    ObjectSetInteger(ChartID(), "NCI_Resistance", OBJPROP_STYLE, STYLE_DOT);
    
    // Support
    ObjectCreate(ChartID(), "NCI_Support", OBJ_HLINE, 0, 0, low20);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_COLOR, clrBlue);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_WIDTH, 1);
    ObjectSetInteger(ChartID(), "NCI_Support", OBJPROP_STYLE, STYLE_DOT);
}

//+------------------------------------------------------------------+
//| DRAW ENTRY/STOP LEVELS                                            |
//+------------------------------------------------------------------+
void DrawEntryStopLevels() {
    double entry_price = GlobalVariableGet("NCI_Entry_Price");
    double stop_loss = GlobalVariableGet("NCI_Stop_Loss");
    
    if (entry_price == 0) return;
    
    datetime current_time = Time[0];
    
    // Entry line
    ObjectCreate(ChartID(), "NCI_Entry_Line", OBJ_HLINE, 0, 0, entry_price);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_COLOR, Color_Entry);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_WIDTH, 3);
    ObjectSetInteger(ChartID(), "NCI_Entry_Line", OBJPROP_STYLE, STYLE_SOLID);
    
    // Stop loss line
    ObjectCreate(ChartID(), "NCI_Stop_Line", OBJ_HLINE, 0, 0, stop_loss);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_COLOR, Color_Stop);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_WIDTH, 3);
    ObjectSetInteger(ChartID(), "NCI_Stop_Line", OBJPROP_STYLE, STYLE_DASH);
    
    // Labels
    DrawText("Entry: " + DoubleToStr(entry_price, 5), 10, 50, Color_Entry, Font_Size, Font_Name);
    DrawText("Stop: " + DoubleToStr(stop_loss, 5), 10, 70, Color_Stop, Font_Size, Font_Name);
}

//+------------------------------------------------------------------+
//| DRAW MAIN DASHBOARD                                               |
//+------------------------------------------------------------------+
void DrawMainDashboard() {
    double entry_price = GlobalVariableGet("NCI_Entry_Price");
    int entry_stage = (int)GlobalVariableGet("NCI_Entry_Stage");
    int scalp_wins = (int)GlobalVariableGet("NCI_Scalp_Count");
    double daily_pnl = GlobalVariableGet("NCI_Daily_PnL");
    double stop_loss = GlobalVariableGet("NCI_Stop_Loss");
    int ema_signal = (int)GlobalVariableGet("NCI_EMA_Signal");
    
    double current_price = Close[0];
    double current_pnl = 0;
    
    if (entry_price > 0) {
        current_pnl = current_price - entry_price;
    }
    
    int y_offset = 30;
    
    // Title
    DrawText("=== NCI TRADING MASTER v3.0 ===", 10, y_offset, clrWhite, 12, "Arial Black");
    y_offset += 25;
    
    // EMA Signal
    color ema_color = clrGray;
    string ema_text = "EMA Gate: ";
    if (ema_signal == 1) {
        ema_text += "BUY ↑";
        ema_color = clrGreen;
    } else if (ema_signal == -1) {
        ema_text += "SELL ↓";
        ema_color = clrRed;
    } else {
        ema_text += "NEUTRAL";
    }
    DrawText(ema_text, 10, y_offset, ema_color, Font_Size, Font_Name);
    y_offset += 20;
    
    // Position Info
    string position_text = "";
    if (entry_stage == 0) {
        position_text = "Position: IDLE";
    } else if (entry_stage == 1) {
        position_text = "Position: 0.01 lots (Entry1)";
    } else if (entry_stage == 2) {
        position_text = "Position: 0.04 lots (Entry2)";
    } else if (entry_stage == 3) {
        position_text = "Position: 0.07 lots (FULL)";
    }
    DrawText(position_text, 10, y_offset, clrYellow, Font_Size, Font_Name);
    y_offset += 20;
    
    // Price & P&L
    if (entry_price > 0) {
        DrawText("Entry: " + DoubleToStr(entry_price, 5), 10, y_offset, Color_Entry, Font_Size, Font_Name);
        y_offset += 18;
        
        DrawText("Current: " + DoubleToStr(current_price, 5) + " (P&L: " + DoubleToStr(current_pnl * 10000, 0) + " pips)", 
                 10, y_offset, clrLime, Font_Size, Font_Name);
        y_offset += 18;
        
        DrawText("Stop: " + DoubleToStr(stop_loss, 5), 10, y_offset, Color_Stop, Font_Size, Font_Name);
        y_offset += 18;
        
        DrawText("Scalp Wins: " + IntegerToString(scalp_wins) + "/3", 10, y_offset, clrMagenta, Font_Size, Font_Name);
        y_offset += 20;
    }
    
    // Daily P&L
    color pnl_color = clrRed;
    if (daily_pnl >= 0) pnl_color = clrLime;
    
    DrawText("Daily P&L: $" + DoubleToStr(daily_pnl, 2) + " | Target: +$10 | Stop: -$5", 
             10, y_offset, pnl_color, Font_Size, Font_Name);
}

//+------------------------------------------------------------------+
//| DRAW STRATEGY SIGNALS                                             |
//+------------------------------------------------------------------+
void DrawStrategySignals() {
    double rsi = iRSI(Symbol(), 0, RSI_Period, PRICE_CLOSE, 0);
    double ma50 = iMA(Symbol(), 0, MA50_Period, 0, MODE_SMA, PRICE_CLOSE, 0);
    double high20 = iHigh(Symbol(), 0, iHighest(Symbol(), 0, MODE_HIGH, MA50_Period, 0));
    double low20 = iLow(Symbol(), 0, iLowest(Symbol(), 0, MODE_LOW, MA50_Period, 0));
    
    int y_offset = 190;
    
    DrawText("=== STRATEGY SIGNALS ===", 10, y_offset, clrWhite, 11, "Arial Black");
    y_offset += 20;
    
    // Breakout Signal
    string breakout_text = "Breakout: ";
    color breakout_color = clrGray;
    if (Close[0] > high20) {
        breakout_text += "BUY (20H) 1.0x";
        breakout_color = clrGreen;
    } else if (Close[0] < low20) {
        breakout_text += "SELL (20L) 1.0x";
        breakout_color = clrRed;
    } else {
        breakout_text += "HOLD";
    }
    DrawText(breakout_text, 10, y_offset, breakout_color, Font_Size, Font_Name);
    y_offset += 18;
    
    // RSI Signal
    string rsi_text = "RSI: ";
    color rsi_color = clrGray;
    if (rsi < 30) {
        rsi_text += "OVERSOLD BUY (0.7x)";
        rsi_color = clrGreen;
    } else if (rsi > 70) {
        rsi_text += "OVERBOUGHT SELL (0.7x)";
        rsi_color = clrRed;
    } else {
        rsi_text += "NEUTRAL";
    }
    DrawText(rsi_text + " RSI=" + DoubleToStr(rsi, 1), 10, y_offset, rsi_color, Font_Size, Font_Name);
    y_offset += 18;
    
    // MA Divergence (Stat Arb)
    string ma_text = "MA Divergence: ";
    color ma_color = clrGray;
    double deviation = MathAbs(Close[0] - ma50) / ma50 * 100;
    if (deviation > 2) {
        ma_text += "DIVERGED (1.2x " + (Close[0] > ma50 ? "SELL" : "BUY") + ")";
        ma_color = (Close[0] > ma50) ? clrRed : clrGreen;
    } else {
        ma_text += "NORMAL";
    }
    DrawText(ma_text, 10, y_offset, ma_color, Font_Size, Font_Name);
    y_offset += 18;
    
    // Engulfing Pattern
    string engulf_text = "Engulfing: ";
    color engulf_color = clrGray;
    if (Close[0] > Open[0] && Open[0] < Low[1] && Close[0] > High[1]) {
        engulf_text += "BULLISH (1.1x)";
        engulf_color = clrGreen;
    } else if (Close[0] < Open[0] && Open[0] > High[1] && Close[0] < Low[1]) {
        engulf_text += "BEARISH (1.1x)";
        engulf_color = clrRed;
    } else {
        engulf_text += "NONE";
    }
    DrawText(engulf_text, 10, y_offset, engulf_color, Font_Size, Font_Name);
}

//+------------------------------------------------------------------+
//| HELPER: Draw Text                                                 |
//+------------------------------------------------------------------+
void DrawText(string text, int x, int y, color clr, int font_size, string font_name) {
    static int counter = 0;
    string obj_name = "NCI_Text_" + IntegerToString(counter++);
    
    ObjectCreate(ChartID(), obj_name, OBJ_LABEL, 0, 0, 0);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_XDISTANCE, x);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_YDISTANCE, y);
    ObjectSetString(ChartID(), obj_name, OBJPROP_TEXT, text);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_COLOR, clr);
    ObjectSetInteger(ChartID(), obj_name, OBJPROP_FONTSIZE, font_size);
    ObjectSetString(ChartID(), obj_name, OBJPROP_FONT, font_name);
}

//+------------------------------------------------------------------+
